# Rift Rumble (working title)

A small, fast arena brawler for Android phones. Every match rolls a different set of
opponents, a weather condition, a pair of weapons and (sometimes) a supply drop.

This is the first playable build (v0.1.0). It is one self-contained HTML file with no
image, audio or library files: all art is drawn in code and all sound is synthesized.
An Android Studio project wraps that file in a full-screen WebView.

## Play it now

- **Any browser, phone or desktop:** open `dist/index.html`. Nothing to install, works offline.
- **On your phone without a build:** copy `dist/index.html` to the phone and open it in Chrome.
- **As an Android app:** see "Build the Android app" below.

### Controls

| Action | Touch | Keyboard |
| --- | --- | --- |
| Move | drag on the movement side of the screen | WASD or arrow keys |
| Attack (three punches make a combo) | ATTACK | J or Space |
| Block (block late to parry) | hold BLOCK | hold K or Shift |
| Dodge | DODGE | L |
| Swap weapon / take the weapon at your feet | SWAP / TAKE | Q |
| Pause | pause button | Esc or P |

Attacks aim at the nearest opponent automatically. A warning cone or line shows where an
opponent is about to strike. Walk over a weapon to pick it up; weapons wear out, fists do not.

## What is in this build

- Main menu, fighter select, match setup (arena, conditions, supply drop, difficulty),
  how-to-play, content-pack roadmap, settings, pause, results.
- One playable fighter (Tamsin Kade) and four opponents (bruiser, duelist, archer, marksman).
- One arena (Sundial Yard) with walls, pillars and crates that block movement and shots.
- Fists with a three-hit combo, plus sword, bow and rifle pickups with limited uses.
- Block, timed parry, dodge with brief invulnerability, health, stamina, guard break.
- Conditions: clear, fog (short sight), rain (slick footing), night (low light); optional supply drop.
- First-match hints, score, stars, best score.
- Settings: language, hints, left/right-handed layout, touch buttons, camera sensitivity,
  vibration, master/effects/music volume, voice lines, subtitles, graphics quality
  (Low is the performance mode), 30 FPS battery saver, frame-rate readout, interface size,
  colorblind-friendly palette, screen shake.
- Localization table (English only for now) and a content registry built for future packs.

Not in this build: more fighters, more arenas, eras, vehicles, the creature survival mode,
online play, accounts, ads, purchases. Those are plans; see `docs/DESIGN.md`.

## Project layout

```
web/                 source
  body.html          page markup (screens and HUD)
  css/style.css      interface styles
  js/i18n.js         every on-screen string, by key  <- translate here
  js/content.js      packs, fighters, weapons, arenas, conditions, difficulty  <- add content here
  js/settings.js     settings and saved data (device-local)
  js/audio.js        synthesized sound, music, voice lines
  js/input.js        keyboard + touch stick and buttons
  js/game.js         match simulation (combat, opponents, pickups, supply drop)
  js/render.js       canvas renderer
  js/ui.js           menus, HUD, hints, subtitles
  js/main.js         boot, app state, main loop
  fonts/             two open-licensed fonts (see docs/licenses)
dist/index.html      built game, single file
android/             Android Studio project (WebView wrapper)
tools/build.mjs      builds dist/ and copies the game into the Android assets
tools/sim.cjs        headless balance and robustness runs
tools/test.cjs       browser end-to-end tests (Playwright)
tools/gallery.cjs    screenshot spot-checks
docs/                design notes, release checklist, privacy policy template, font licenses
```

## Build and test

Requires Node.js 18 or newer. The tests also need Playwright with Chromium
(`npm i -D playwright && npx playwright install chromium`).

```
node tools/build.mjs        # writes dist/index.html and android/app/src/main/assets/index.html
node tools/sim.cjs 60       # ~900 simulated matches: no crashes, no stuck matches, win rates
node tools/test.cjs         # 46 browser checks: menus, touch, keyboard, win, lose, pause, settings, i18n
```

## Build the Android app

The Android project was written but **not compiled or run on a device** in the environment
that produced it (the Android SDK could not be downloaded there). Treat the first build as
a real first build.

1. Install Android Studio (current stable). Open the `android/` folder as a project.
2. Let it sync. If it offers to upgrade the Android Gradle Plugin or Gradle, accept.
   Install "Android SDK Platform 36" if prompted.
3. Plug in a phone with USB debugging on (or start an emulator) and press Run.
4. For Google Play you need an Android App Bundle: Build > Generate Signed App Bundle.

Before publishing, change `applicationId` in `android/app/build.gradle`, the app name in
`res/values/strings.xml`, and replace the placeholder launcher icon.

The wrapper asks for no internet permission. It adds one bridge so voice lines can use the
phone's text-to-speech engine, handles the Back button, and hides the system bars.

## Add a language

Copy the `en` table in `web/js/i18n.js`, translate the values, register it under a new code
with a `_name`. It appears in Settings > Language automatically. Missing keys fall back to
English. `RR.makePseudoLocale()` in the browser console wraps every string in brackets so
untranslated text is easy to spot; `tools/test.cjs` uses it to check that nothing on screen
is hard-coded. The bundled fonts cover Latin script only; other scripts use the device font.

## Add a content pack

In `web/js/content.js`: set the pack to `status: 'installed'`, add its arenas to `RR.ARENAS`
(size, walls, spawn points, obstacles), fighters to `RR.FIGHTERS`, weapons to `RR.WEAPONS`,
and add their names to the locale table. The menus read from these tables. New obstacle
shapes or fighter looks need a draw function in `web/js/render.js`.

## Licenses

Game code and design: yours to license as you choose. Fonts: Big Shoulders Display and
Barlow Semi Condensed, SIL Open Font License 1.1 (texts in `docs/licenses/`; keep them with
any copy of the app that includes the fonts).
