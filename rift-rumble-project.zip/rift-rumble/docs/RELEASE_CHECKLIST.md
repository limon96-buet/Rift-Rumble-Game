# Google Play release checklist

Requirements below were checked against Google's own pages on 11 November 2026. Play
policy changes several times a year: re-read the linked pages before you submit. This is
not legal advice.

## Where this build stands

| Requirement | Status in this project |
| --- | --- |
| Target API level 36 (Android 16) for new apps and updates | Set in `android/app/build.gradle` (`targetSdk 36`). Not yet built or run. |
| Android App Bundle (.aab) upload | You build it in Android Studio. |
| No sensitive permissions | Only VIBRATE. No internet, location, contacts, storage, camera or microphone. |
| Data collection | None. Settings and best score stay on the device. |
| Ads / purchases | None in this build. |
| Privacy note inside the app | Settings > About. A hosted policy URL is still needed (template in `docs/`). |
| Content rating | Not done. You complete the questionnaire in Play Console. |
| Real-device testing | Not done. Tested only in desktop Chromium with phone-size emulation. |

## Things only you can do

1. **Create a Play Console developer account.** One-time US$25 fee, you must be 18 or older,
   and Google verifies your identity (a government ID and a card in your legal name may be
   asked for). Personal accounts must also verify access to a real Android device through
   the Play Console mobile app before publishing.
   Bangladesh is listed as supported for both developer and merchant registration.
2. **Run the required closed test.** Personal accounts created after 13 November 2023 must
   run a closed test with at least 12 testers opted in continuously for 14 days before
   they can apply for production access. Then you answer questions about the test, the app
   and its readiness. Plan for this: it adds at least two weeks, and you need 12 real people.
3. **Pick the final name and app ID.** "Rift Rumble" is already used by at least one other
   game online, so choose another name (ideas in `docs/DESIGN.md`), search Google Play and
   the trademark registers for the countries you care about, then set `applicationId`
   (permanent after first upload), the app name and the icon.
4. **Build, sign and test.** Generate a signed App Bundle, enrol in Play App Signing, keep
   your upload key safe and backed up. Play the game on at least two real phones, one of
   them low-end, in every condition and on Low graphics.
5. **Host a privacy policy.** Google requires a privacy policy link on the store listing
   and in the app for all apps, including apps that collect nothing. Adapt
   `docs/PRIVACY_POLICY_TEMPLATE.md`, publish it at a public URL, and put that URL in
   Play Console. If you later add ads, analytics or purchases, the policy must change first.
6. **Complete the App content declarations** in Play Console:
   - Privacy policy (all apps).
   - Ads: declare that the app contains no ads (change it if you add them).
   - Target audience and content: choose age groups honestly. Including children under 13
     brings the Families policy into force; a combat game is usually easier to ship with
     an older target audience.
   - Content rating questionnaire (all apps; unrated apps can be removed). Answer
     accurately: the game has stylized, non-graphic fighting between human-like characters
     with fists, swords, bows and a rifle, no blood, no gore. The rating is decided by the
     questionnaire, not by you or me.
   - Data safety form (required for closed, open and production tracks, even when no data
     is collected; internal testing is exempt). For this build: no data collected, no data
     shared.
   - App access / sign-in details: not needed, nothing is behind a login.
7. **Prepare the store listing.** App name, short and full description, icon, feature
   graphic and phone screenshots (check the current size rules in Play Console). Describe
   only what the build contains: one fighter, four opponents, one arena. Do not list
   planned packs as features.
8. **Check Android developer verification status** in Play Console. Google is rolling
   this out to all developers; enforcement began 30 September 2026 in Brazil, Indonesia,
   Singapore and Thailand and is due to expand globally in 2027. Developers who completed
   Play Console identity verification are treated as verified, but confirm each app shows
   as registered.
9. **If you add monetization later:** set up a payments profile (merchant account), tax
   and bank details; use Google Play Billing for digital goods; update the ads declaration,
   Data safety form and privacy policy; add consent prompts where the law requires them.
   Adding an ads SDK means adding the internet permission and usually collecting device
   identifiers, which changes most of the answers above.

## Policy points that shape future content

- Keep violence stylized and non-graphic, keep weapons fictional or generic, and never
  present anything as real-world instruction. Check Google Play's Inappropriate Content
  and Violence policies before adding vehicles, aircraft or missiles.
- Do not use real countries' current conflicts, real military units, real people, or real
  brands. "Historical-inspired" settings are safer as invented places.
- The creature survival mode should avoid animal cruelty: creatures are fictional, can be
  avoided or scared off, and are not shown suffering.
- Everything in the game, the listing and the screenshots must be your own original work
  or properly licensed.

## Sources

- [Target API level requirements](https://developer.android.com/google/play/requirements/target-sdk) (Android Developers)
- [App testing requirements for new personal developer accounts](https://support.google.com/googleplay/android-developer/answer/14151465?hl=en) (Play Console Help)
- [Get started with Play Console: fee, age, identity and device verification](https://support.google.com/googleplay/android-developer/answer/6112435?hl=en) (Play Console Help)
- [Supported locations for developer and merchant registration](https://support.google.com/googleplay/android-developer/answer/9306917) (Play Console Help)
- [Prepare your app for review: App content declarations](https://support.google.com/googleplay/android-developer/answer/9859455?hl=en) (Play Console Help)
- [Provide information for Google Play's Data safety section](https://support.google.com/googleplay/android-developer/answer/10787469?hl=en) (Play Console Help)
- [Android developer verification: rolling out to all developers](https://android-developers.googleblog.com/2026/03/android-developer-verification-rolling-out-to-all-developers.html) (Android Developers Blog, March 2026)
- [Summary of the July 2026 Play policy update](https://dev.to/mr_manushukla/google-plays-july-2026-policy-update-5-changes-to-ship-before-the-31-august-deadline-3bie) (secondary source; confirm against Play Console's Policy Center)

Not checked this session, so confirm in Play Console: the exact store-listing image sizes,
the Android App Bundle requirement wording, and whether Google has announced the 2027
target API deadline yet.
