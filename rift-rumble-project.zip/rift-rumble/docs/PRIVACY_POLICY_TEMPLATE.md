# Privacy policy template

This is a starting draft for the build as it is today (offline, no accounts, no ads, no
purchases, no analytics). Replace the bracketed parts, have it reviewed if you can, and
publish it at a public web address. It stops being accurate the moment you add ads,
analytics, purchases, online play or any library that uses the network.

---

**Privacy Policy for [Game Name]**

Last updated: [date]

[Developer or company name] ("we") publishes [Game Name] (the "game").

**Data we collect.** None. The game does not collect, transmit or share personal data.
It does not use the internet and it does not contain advertising, analytics or
third-party tracking tools.

**Data stored on your device.** The game saves your settings and your best score on your
device so they are there the next time you play. This information never leaves your
device. You can erase it with "Reset all settings" in the game, by clearing the app's
storage in Android settings, or by uninstalling the game.

**Permissions.** The game asks only for the vibration permission, used for optional
feedback when your fighter is hit. If voice lines are turned on, the game asks your
device's built-in text-to-speech engine to speak short lines; this happens on your device.

**Children.** The game does not knowingly collect personal data from anyone, including
children.

**Changes.** If a future version changes how data is handled, we will update this policy
and the date above before that version is released.

**Contact.** [Your contact email address]
