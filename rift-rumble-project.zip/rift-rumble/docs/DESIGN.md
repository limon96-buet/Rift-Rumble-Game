# Design notes

## Pitch

A two-minute arena brawl where the match itself is the surprise. You always know your
fighter. You never know who walks in, what the sky is doing, or which weapons are lying
on the ground. Short matches, clear warnings, readable hits.

## Name ideas

"Rift Rumble" is already in use by at least one other game found in a web search, so
plan to rename before release. Candidates (a quick search found no game with these exact
names, which is not a trademark clearance):

- **Sundial Rumble** — ties the name to the arena and the time-shifting theme.
- **Riftyard** — one word, easy to say, easy to make a logo from.
- **Stormcard Brawl** — leans on the "every match is a different fight card" idea.
- **Yard of Eras** — signals the long-term era packs.
- **Shatterdial** — the broken sundial as the game's symbol.

## Match loop (built)

1. Fight card: fighter vs. the rolled opponents, with conditions and weapons listed.
2. Opponents enter one after another; at most two are in the yard at once.
3. Read warnings, block or dodge, answer with combos, grab weapons.
4. Optional supply drop mid-match: a marked crate with a medkit and a third weapon.
5. Results: score, up to three stars (win, finish above half health, finish within 90 s).

Combat rules worth knowing when tuning (`web/js/content.js`, `web/js/game.js`):

- Opponents telegraph every attack. Wind-up times scale with difficulty.
- Opponents flinch when hit but brace after a finisher or three quick hits, so
  button-mashing cannot stun-lock them.
- Blocking costs stamina; an empty stamina bar breaks your guard. A block in the last
  0.2 s is a parry: no damage, attacker staggered.
- Only a limited number of opponents may attack at the same time (1 on Easy, 2 otherwise).
- Simulated win rates from `tools/sim.cjs` (scripted players, not people): a player who
  only attacks wins about 70% of Normal and almost never on Hard; one who blocks on
  warnings wins nearly every Normal match and roughly 60–70% of Hard.

## Art and interface direction

Fight-poster look: slanted condensed display type, gold slabs, hazard dashes, one pink
"rift" accent. Fighters are simple top-down figures with one distinguishing shape each
(scarf, shoulder plates, ponytail, hood, hat brim), so they read at 40 pixels. Team is
shown by ring style (solid for you, dashed for opponents) and a marker shape as well as
color. Everything is drawn in code, which keeps the download small and makes palette
swaps free.

## Content packs (planned, not built)

The code keeps all content in data tables grouped by pack id (`RR.PACKS`). The menus
already list planned packs as "Planned" so the structure is visible without pretending
the content exists.

| Pack | Idea | New systems needed |
| --- | --- | --- |
| Ancient and Medieval Fields | Invented kingdoms: shield walls, spears, stone forts | Shields as equipment, spear reach |
| Early 1900s | Fictional rail yards and airship docks | Moving hazards (carts), cover that breaks |
| Modern and Future Fronts | Invented battlefields with drones and energy weapons | Vehicles as arena hazards or brief power-ups, fictional missiles as telegraphed area attacks |
| Climates and Seasons | Snow, desert, monsoon, autumn variants | New condition rules (ice slide, heat haze, wind on arrows) |
| Prehistoric Survival | Separate mode, see below | Creature behaviors, stealth, exits |

Guidelines for every pack: invented places and peoples, no real nations' current
conflicts, no real brands or characters, cultural inspiration researched and credited,
and no promise of "every country" or "every period".

### Creature survival mode

A separate mode, not a reskin of the brawl. Goal: reach the exit or last until dawn.

- Creatures are fictional and stylized (invented dinosaurs and beasts).
- The player's tools are non-lethal first: hide in tall grass, throw a noise lure, light
  a flare to scare, slam a gate, climb out of reach.
- Creatures that are driven off run away; nothing is shown suffering, bleeding or dying.
- Scoring rewards avoidance and escapes, not harm.

## What stays in the base download, what comes later

The base game is about 0.2 MB of HTML today, so the APK should be small (not measured:
it has not been built). To keep it that way:

- **Base app:** engine, menus, Core pack, English.
- **Optional downloads later:** each era pack's arenas and fighters, recorded voice
  packs per language, longer music. On Google Play this is done with Play Feature
  Delivery or Play Asset Delivery (on-demand delivery), so players fetch only the packs
  they choose. While packs are still code-drawn they are only a few kilobytes each and
  can simply ship in the base app.
- **Online features:** none in the MVP. Leaderboards or cloud saves would add network
  access, an account system and data-safety obligations; add them only when there is a
  clear reason.

## Accessibility

Built: large touch targets (48 px or more at the default interface size), interface size 80–130%, left-handed layout,
colorblind-friendly palette, shapes and dashed outlines in addition to color, subtitles
for all voice lines, adjustable camera, screen-shake and vibration toggles, keyboard
play, reduced-motion support for menu animation.

Worth adding: remappable keys, gamepad support, a hold-to-attack option, a
high-contrast outline mode, and a slower game-speed option.

## Monetization plan (suggested, optional, not built)

Principles: nothing sold changes who wins; every price is shown before purchase; no loot
boxes, no timers to pay past, no "continue for coins"; the full Core game is free.
Nothing here guarantees income; most mobile games earn little, so treat revenue as
uncertain and keep costs low.

1. **Launch free with no ads and no purchases.** It makes the closed test and first
   review simple and lets you learn whether people replay it.
2. **Cosmetics, directly priced.** Fighter outfits and scarf colors, arena banners,
   announcer voice packs, hit-spark styles. Show the item and the price; no random draws.
3. **Content packs as one-time purchases.** Each era pack adds arenas, opponents and
   weapons with the same balance rules as the Core pack. A bundle price can cover all
   current packs. Players who do not buy can still finish everything in Core.
4. **Optional rewarded ads only.** For example: watch an ad to preview a cosmetic for a
   day. No banner or interstitial ads between matches, no ads that grant health, damage
   or revives. If the audience may include children, skip ads entirely.
5. **A supporter purchase.** One clearly labelled tip that unlocks a cosmetic badge.

Each of these needs work outside the game: a payments profile, Play Billing integration,
updated Data safety answers and privacy policy, refunds handling, and tax setup.

## Roadmap after this build

1. Run it on real phones; fix whatever touch feel and performance problems show up.
2. Second fighter and second arena, to prove the pack tables hold up.
3. Recorded sound effects and a short music loop, still under a few hundred kilobytes.
4. First era pack as the on-demand delivery test.
5. Survival mode prototype.
