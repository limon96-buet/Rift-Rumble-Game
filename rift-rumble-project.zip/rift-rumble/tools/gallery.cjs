// Visual spot-checks: captures specific combat moments for manual review (not pass/fail).
const { chromium } = require('playwright');
const path = require('path');
(async () => {
  const b = await chromium.launch();
  const ctx = await b.newContext({ viewport: { width: 1000, height: 520 } });
  const page = await ctx.newPage();
  const errs = [];
  page.on('pageerror', (e) => errs.push(e.message));
  await page.goto('file://' + path.resolve(__dirname, '..', 'dist', 'index.html'));
  const shot = (n) => page.screenshot({ path: path.join(__dirname, 'shots', 'g-' + n + '.png') });
  const startWith = async (first, cond) => {
    await page.evaluate(([first, cond]) => {
      RR.setSetting('hints', false); RR.setSetting('voice', false);
      for (let seed = 1; seed < 500; seed++) { RR.app.startMatch({ seed, cond, supply: 'off', skipIntro: true }); if (RR.game.M.lineup[0] === first) return; }
    }, [first, cond]);
  };
  // 1. melee telegraph
  await startWith('brakk', 'clear');
  await page.waitForFunction(() => { const e = RR.game.M.fighters[1]; return e && e.atk && e.atk.phase === 'w' && e.atk.t > e.atk.wd * 0.6; }, null, { timeout: 30000 });
  await shot('melee-telegraph');
  // 2. ranged telegraph at night
  await startWith('dax', 'night');
  await page.waitForFunction(() => { const e = RR.game.M.fighters[1]; return e && e.atk && e.atk.phase === 'w' && e.atk.t > e.atk.wd * 0.85; }, null, { timeout: 30000 });
  await shot('ranged-telegraph-night');
  // 3. player sword swing next to an opponent, colorblind palette
  await startWith('sable', 'clear');
  await page.evaluate(() => RR.setSetting('colorblind', true));
  await page.waitForFunction(() => RR.game.M.fighters[1] && RR.game.M.fighters[1].spawnT <= 0, null, { timeout: 30000 });
  await page.evaluate(() => { const M = RR.game.M; M.player.weapon = { id: 'sword', uses: 16 }; });
  await page.waitForFunction(() => { const M = RR.game.M, e = M.fighters[1]; return e && Math.hypot(e.x - M.player.x, e.y - M.player.y) < 110; }, null, { timeout: 30000 });
  await page.keyboard.press('KeyJ');
  await page.waitForFunction(() => { const a = RR.game.M.player.atk; return a && a.phase === 'a' && a.t > 0.04; }, null, { timeout: 5000 }).catch(() => {});
  await shot('sword-colorblind');
  // 4. blocking with the bow in hand in rain
  await page.evaluate(() => RR.setSetting('colorblind', false));
  await startWith('quill', 'rain');
  await page.waitForFunction(() => RR.game.M.fighters[1] && RR.game.M.fighters[1].spawnT <= 0, null, { timeout: 30000 });
  await page.evaluate(() => { RR.game.M.player.weapon = { id: 'bow', uses: 9 }; });
  await page.keyboard.press('KeyJ');
  await page.waitForFunction(() => RR.game.M.projectiles.some((p) => p.team === 'player'), null, { timeout: 5000 }).catch(() => {});
  await shot('bow-rain');
  console.log('gallery done, page errors:', errs.length ? errs : 'none');
  await b.close();
})();
