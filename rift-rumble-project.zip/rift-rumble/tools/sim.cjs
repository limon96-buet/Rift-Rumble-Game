// Headless balance and robustness check: runs seeded matches through the real simulation
// (web/js/game.js) with simple scripted players. Usage: node tools/sim.cjs [matchesPerCell]
const fs = require('fs'), path = require('path'), vm = require('vm');
const web = path.join(__dirname, '..', 'web', 'js');
const sandbox = { window: {}, Math, console };
sandbox.window.RR = {
  audio: { sfx() {} }, vibrate() {}, settings: { cam: 1 }, view: { w: 995, h: 460 }, fxCap: 140,
};
vm.createContext(sandbox);
for (const f of ['i18n.js', 'content.js', 'game.js']) vm.runInContext(fs.readFileSync(path.join(web, f), 'utf8'), sandbox, { filename: f });
const RR = sandbox.window.RR;
const hyp = Math.hypot;

function bot(policy, M, inp) {
  inp.mx = inp.my = 0; inp.attackPressed = inp.dodgePressed = inp.swapPressed = false; inp.block = false;
  if (policy === 'idle') return;
  const p = M.player;
  let tgt = null, td = 1e9, threat = null;
  for (const f of M.fighters) {
    if (f.team !== 'enemy' || f.state === 'dead' || f.spawnT > 0) continue;
    const d = hyp(f.x - p.x, f.y - p.y);
    if (d < td) { td = d; tgt = f; }
    if (f.atk && f.atk.phase !== 'r') {
      const W = f.atk.W;
      if (W.kind === 'ranged' || d < W.range + W.lunge + 40) threat = f;
    }
  }
  const W = RR.game.wepOf(p);
  if (policy === 'dodger' && threat) {
    // dodge sideways just before the strike lands
    const a = threat.atk;
    if (a.phase === 'a' || a.wd - a.t < 0.12) { inp.dodgePressed = true; inp.mx = -(threat.y - p.y) / (td || 1); inp.my = (threat.x - p.x) / (td || 1); }
    return;
  }
  if (policy === 'turtle') { inp.block = true; return; }
  if (policy === 'smart' || policy === 'dodger') {
    if (threat) { inp.block = true; return; }
    const S = M.supply;
    if (S && S.state === 'landed') { const d = hyp(S.x - p.x, S.y - p.y); inp.mx = (S.x - p.x) / d; inp.my = (S.y - p.y) / d; return; }
    // go for a weapon when unarmed and one is close
    if (!p.weapon) {
      let k = null, kd = 260;
      for (const q of M.pickups) { if (q.kind !== 'weapon') continue; const d = hyp(q.x - p.x, q.y - p.y); if (d < kd) { kd = d; k = q; } }
      if (k && (!tgt || td > 150)) { inp.mx = (k.x - p.x) / kd; inp.my = (k.y - p.y) / kd; return; }
    }
    if (p.hp < 60) {
      let k = null, kd = 400;
      for (const q of M.pickups) { if (q.kind === 'weapon') continue; const d = hyp(q.x - p.x, q.y - p.y); if (d < kd) { kd = d; k = q; } }
      if (k) { inp.mx = (k.x - p.x) / kd; inp.my = (k.y - p.y) / kd; return; }
    }
  }
  if (!tgt) return;
  const reach = W.kind === 'melee' ? W.range * 0.8 : 420;
  if (td > reach || (W.kind === 'ranged' && !RR.game.los(p.x, p.y, tgt.x, tgt.y))) {
    // crude obstacle dodge: add a sideways component when not making progress
    let dx = (tgt.x - p.x) / td, dy = (tgt.y - p.y) / td;
    if (M._stuck > 0.4) { const t = dx; dx = dx * 0.3 - dy; dy = dy * 0.3 + t; }
    inp.mx = dx; inp.my = dy;
  }
  if (td <= reach + 30 && p.st > 12) inp.attackPressed = (M._tick % 4) === 0;
}

function run(policy, diff, seed, cond) {
  const M = RR.game.newMatch({ seed, diff, cond, skipIntro: true });
  const inp = { mx: 0, my: 0, attackPressed: false, block: false, dodgePressed: false, swapPressed: false };
  M._tick = 0; M._stuck = 0;
  let lx = M.player.x, ly = M.player.y, steps = 0, hadWeapon = false;
  const seen = M._seen = {};
  const T = { dodge: RR.t('fx.dodge'), parry: RR.t('fx.parry'), gbreak: RR.t('fx.break'), empty: RR.t('fx.empty'), broken: RR.t('fx.broken') };
  while (M.phase !== 'over' && steps < 60 * 400) {
    bot(policy, M, inp);
    RR.game.update(1 / 60, inp);
    const p = M.player;
    for (const t of M.texts) for (const k in T) if (t.txt === T[k]) seen[k] = true;
    if (p.weapon) { hadWeapon = true; seen['weapon:' + p.weapon.id] = true; }
    if (M.supply && M.supply.state === 'open') seen.supplyOpen = true;
    if (M.pickups.some((q) => q.kind === 'medkit')) seen.medkit = true;
    if (M.pickups.some((q) => q.kind === 'health')) seen.orb = true;
    if (!isFinite(p.x) || !isFinite(p.y) || !isFinite(p.hp)) throw new Error('NaN in player state, seed ' + seed);
    for (const f of M.fighters) if (!isFinite(f.x) || !isFinite(f.y)) throw new Error('NaN in fighter, seed ' + seed);
    const moved = hyp(p.x - lx, p.y - ly);
    M._stuck = (inp.mx || inp.my) && moved < 0.5 ? M._stuck + 1 / 60 : Math.max(0, M._stuck - 1 / 30);
    lx = p.x; ly = p.y; M._tick++; steps++;
  }
  RR.game.events.length = 0;
  for (const k in seen) COVER[k] = (COVER[k] || 0) + 1;
  return { result: M.result, t: M.t, hp: M.player.hp, over: M.phase === 'over', score: M.score, stars: M.stars, defeated: M.defeated, n: M.lineup.length };
}

const COVER = {};
const N = +process.argv[2] || 60;
let bad = 0;
for (const diff of ['easy', 'normal', 'hard']) {
  for (const policy of ['idle', 'masher', 'smart']) {
    let wins = 0, tsum = 0, stuck = 0, hp = 0, stars = 0;
    for (let i = 0; i < N; i++) {
      const r = run(policy, diff, 1000 + i * 7919, undefined);
      if (!r.over) { stuck++; bad++; continue; }
      if (r.result === 'win') { wins++; hp += r.hp; stars += r.stars; }
      tsum += r.t;
    }
    console.log(`${diff.padEnd(6)} ${policy.padEnd(6)} win ${(100 * wins / N).toFixed(0).padStart(3)}%  avg ${(tsum / Math.max(1, N - stuck)).toFixed(0).padStart(3)}s  avgHpOnWin ${(hp / Math.max(1, wins)).toFixed(0).padStart(3)}  avgStars ${(stars / Math.max(1, wins)).toFixed(1)}  unfinished ${stuck}`);
  }
}
for (const cond of ['clear', 'fog', 'rain', 'night']) {
  let wins = 0;
  for (let i = 0; i < N; i++) { const r = run('smart', 'normal', 5 + i * 31, cond); if (!r.over) bad++; if (r.result === 'win') wins++; }
  console.log(`normal smart cond=${cond.padEnd(5)} win ${(100 * wins / N).toFixed(0)}%`);
}
for (const policy of ['dodger', 'turtle']) {
  let wins = 0;
  for (let i = 0; i < N; i++) { const r = run(policy, 'normal', 77 + i * 13, undefined); if (!r.over) bad++; if (r.result === 'win') wins++; }
  console.log(`normal ${policy.padEnd(6)} win ${(100 * wins / N).toFixed(0)}%`);
}
console.log('feature coverage (matches in which each thing happened):', JSON.stringify(COVER));
const need = ['dodge', 'parry', 'gbreak', 'empty', 'broken', 'supplyOpen', 'medkit', 'orb', 'weapon:sword', 'weapon:bow', 'weapon:rifle'];
const missing = need.filter((k) => !COVER[k]);
if (missing.length) { console.log('FAIL: never observed: ' + missing.join(', ')); bad++; }
console.log(bad ? 'FAIL: ' + bad + ' unfinished matches' : 'OK: every match reached an end state, no NaN');
process.exit(bad ? 1 : 0);
