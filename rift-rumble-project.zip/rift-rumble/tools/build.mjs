// Rift Rumble build: inlines CSS, JS and fonts into single self-contained HTML files.
//   dist/index.html              full document (open in a browser, or ship inside the Android app)
//   dist/rift-rumble.page.html   body-only fragment for hosts that add their own <html> skeleton
// Usage: node tools/build.mjs
import { readFileSync, writeFileSync, mkdirSync, copyFileSync, existsSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const web = join(root, 'web');
const read = (p) => readFileSync(join(web, p), 'utf8');
const b64 = (p) => readFileSync(join(web, p)).toString('base64');

const JS = ['i18n', 'content', 'settings', 'audio', 'input', 'game', 'render', 'ui', 'main'];
const fonts = `
@font-face { font-family: "Big Shoulders Display"; font-weight: 900; font-style: normal; font-display: swap;
  src: url(data:font/woff2;base64,${b64('fonts/display.woff2')}) format("woff2"); }
@font-face { font-family: "Barlow Semi Condensed"; font-weight: 500 700; font-style: normal; font-display: swap;
  src: url(data:font/woff2;base64,${b64('fonts/ui.woff2')}) format("woff2"); }`;
const css = fonts + '\n' + read('css/style.css');
const js = JS.map((n) => `/* ---- ${n}.js ---- */\n` + read(`js/${n}.js`)).join('\n');
const body = read('body.html');
if (js.includes('</script')) throw new Error('script text would close the script tag');

const fragment = `<title>Rift Rumble</title>
<meta name="claude:viewport-fit-sides" content="cover">
<style>${css}</style>
${body}
<script>
${js}
</script>
`;
const full = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, viewport-fit=cover">
<meta name="theme-color" content="#0c171c">
<meta name="mobile-web-app-capable" content="yes">
<title>Rift Rumble</title>
<style>${css}</style>
</head>
<body>
${body}
<script>
${js}
</script>
</body>
</html>
`;
mkdirSync(join(root, 'dist'), { recursive: true });
writeFileSync(join(root, 'dist/index.html'), full);
writeFileSync(join(root, 'dist/rift-rumble.page.html'), fragment);
const assets = join(root, 'android/app/src/main/assets');
if (existsSync(join(root, 'android/app/src/main'))) {
  mkdirSync(assets, { recursive: true });
  copyFileSync(join(root, 'dist/index.html'), join(assets, 'index.html'));
}
console.log('built dist/index.html', (full.length / 1024).toFixed(1) + ' KB');
