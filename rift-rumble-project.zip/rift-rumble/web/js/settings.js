/* Rift Rumble — settings and small saved data (device-local only; nothing leaves the device). */
(function () {
  const RR = (window.RR = window.RR || {});
  const KEY = 'riftrumble.v1';

  RR.DEFAULTS = {
    language: 'en',
    hints: true,
    layout: 'right', // 'right' | 'left'
    touch: 'auto', // 'auto' | 'always'
    uiScale: 1, // 0.8 .. 1.3
    cam: 1, // 0.5 .. 1.5
    vibrate: true,
    master: 0.8,
    sfx: 0.9,
    music: 0.5,
    voice: true,
    subs: true,
    quality: 'med', // 'low' | 'med' | 'high'
    fps30: false,
    showFps: false,
    shake: true,
    colorblind: false,
    // match setup (remembered between matches)
    cond: 'random',
    supply: 'random',
    diff: 'normal',
  };

  const store = { settings: Object.assign({}, RR.DEFAULTS), best: 0, hintsDone: false, plays: 0 };

  function load() {
    try {
      const raw = window.localStorage.getItem(KEY);
      if (!raw) return;
      const data = JSON.parse(raw);
      if (data && typeof data === 'object') {
        if (data.settings) {
          for (const k in RR.DEFAULTS) {
            if (typeof data.settings[k] === typeof RR.DEFAULTS[k]) store.settings[k] = data.settings[k];
          }
        }
        store.best = +data.best || 0;
        store.hintsDone = !!data.hintsDone;
        store.plays = +data.plays || 0;
      }
    } catch (e) {
      /* storage blocked or empty: run with defaults */
    }
  }

  function save() {
    try {
      window.localStorage.setItem(KEY, JSON.stringify(store));
    } catch (e) {
      /* ignore */
    }
  }

  const listeners = [];
  RR.settings = store.settings;
  RR.save = store;
  RR.persist = save;
  RR.onSetting = (fn) => listeners.push(fn);
  RR.setSetting = function (key, value) {
    store.settings[key] = value;
    save();
    listeners.forEach((fn) => fn(key, value));
  };
  RR.resetSettings = function () {
    for (const k in RR.DEFAULTS) store.settings[k] = RR.DEFAULTS[k];
    store.hintsDone = false;
    save();
    listeners.forEach((fn) => fn('*'));
  };

  load();
  if (!RR.LOCALES[store.settings.language]) store.settings.language = 'en';
  RR.locale = store.settings.language;
})();
