/* Rift Rumble — renderer. Canvas 2D, all art drawn from code (no image files). */
(function () {
  const RR = (window.RR = window.RR || {});
  const TAU = Math.PI * 2;
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  let cv, ctx, ground = null, groundKey = '', dark = null, dctx = null;
  let cw = 0, ch = 0, zoom = 1, scale = 1, time = 0;
  const view = (RR.view = { w: 820, h: 460 });

  const PALS = {
    normal: {
      player: '#35e0c8', playerDk: '#0f7f72', enemy: '#ff6a3d', enemyDk: '#9c3115', warn: '255,96,56',
      gold: '#ffc02e', rift: '#ff4f8b', bone: '#f4ecd8',
      looks: { bruiser: '#d9532e', duelist: '#e8457a', archer: '#f08a2c', gunner: '#c2463f' },
    },
    cb: {
      player: '#5ab0ff', playerDk: '#1d5a9e', enemy: '#ffa01e', enemyDk: '#8f5400', warn: '255,176,40',
      gold: '#ffe27a', rift: '#d7b5ff', bone: '#f4ecd8',
      looks: { bruiser: '#e08a00', duelist: '#ffb84d', archer: '#d97706', gunner: '#f5c26b' },
    },
  };
  let P = PALS.normal;

  /* ---- sizing ---------------------------------------------------------- */
  function resize() {
    if (!cv) return;
    const w = cv.clientWidth || 1, h = cv.clientHeight || 1, dpr = window.devicePixelRatio || 1, q = RR.settings.quality;
    scale = q === 'low' ? Math.min(dpr, 1) * 0.75 : q === 'med' ? Math.min(dpr, 1.5) : Math.min(dpr, 2);
    cw = Math.max(1, Math.round(w * scale));
    ch = Math.max(1, Math.round(h * scale));
    if (cv.width !== cw) cv.width = cw;
    if (cv.height !== ch) cv.height = ch;
    const cssZoom = Math.min(1.5, Math.max(Math.min(w / 820, h / 460), Math.min(w / 460, h / 820)));
    zoom = cssZoom * scale;
    view.w = w / cssZoom;
    view.h = h / cssZoom;
    RR.fxCap = q === 'low' ? 40 : q === 'med' ? 140 : 280;
    dark = null;
  }

  /* ---- helpers --------------------------------------------------------- */
  function ell(x, y, rx, ry) { ctx.beginPath(); ctx.ellipse(x, y, rx, ry, 0, 0, TAU); ctx.fill(); }
  function circ(c, x, y, r) { c.beginPath(); c.arc(x, y, r, 0, TAU); }
  function rrect(c, x, y, w, h, r) {
    c.beginPath();
    c.moveTo(x + r, y); c.lineTo(x + w - r, y); c.quadraticCurveTo(x + w, y, x + w, y + r);
    c.lineTo(x + w, y + h - r); c.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
    c.lineTo(x + r, y + h); c.quadraticCurveTo(x, y + h, x, y + h - r);
    c.lineTo(x, y + r); c.quadraticCurveTo(x, y, x + r, y); c.closePath();
  }
  function lcg(s) { return () => ((s = (Math.imul(s, 1664525) + 1013904223) >>> 0) / 4294967296); }

  const CRACK = [[46, 430], [150, 452], [250, 420], [370, 470], [470, 446], [590, 492], [690, 468], [750, 475], [820, 486], [930, 452], [1040, 500], [1150, 470], [1260, 512], [1370, 484], [1454, 505]];

  /* ---- static arena art, cached once per match ------------------------- */
  function buildGround(arenaId, cond) {
    const A = RR.ARENAS[arenaId], key = arenaId + '|' + cond + '|' + RR.settings.quality;
    if (ground && groundKey === key) return;
    groundKey = key;
    const gs = RR.settings.quality === 'low' ? 0.5 : 1;
    ground = document.createElement('canvas');
    ground.width = Math.round(A.w * gs);
    ground.height = Math.round(A.h * gs);
    ground.gs = gs;
    const g = ground.getContext('2d');
    g.scale(gs, gs);
    const rnd = lcg(7), wall = A.wall, wet = cond === 'rain';
    g.fillStyle = '#081116';
    g.fillRect(0, 0, A.w, A.h);
    g.fillStyle = wet ? '#2c4247' : '#39545a';
    g.fillRect(wall, wall, A.w - wall * 2, A.h - wall * 2);
    // flagstones
    const ts = 96;
    for (let ry = 0, row = 0; ry < A.h; ry += ts, row++) {
      for (let rx = row % 2 ? -ts / 2 : 0; rx < A.w; rx += ts) {
        const v = rnd();
        g.fillStyle = v < 0.5 ? 'rgba(255,255,255,' + (0.015 + v * 0.07) + ')' : 'rgba(0,0,0,' + (v - 0.5) * 0.16 + ')';
        g.fillRect(rx + 2, ry + 2, ts - 4, ts - 4);
      }
    }
    g.fillStyle = '#081116';
    g.fillRect(0, 0, A.w, wall); g.fillRect(0, A.h - wall, A.w, wall); g.fillRect(0, 0, wall, A.h); g.fillRect(A.w - wall, 0, wall, A.h);
    // sundial inlay
    const cx = A.w / 2, cy = A.h / 2;
    g.strokeStyle = 'rgba(214,170,84,0.55)';
    g.lineWidth = 7; circ(g, cx, cy, 230); g.stroke();
    g.lineWidth = 3; circ(g, cx, cy, 170); g.stroke(); circ(g, cx, cy, 96); g.stroke();
    for (let i = 0; i < 24; i++) {
      const a = (i / 24) * TAU, r0 = i % 2 ? 196 : 176, c = Math.cos(a), s = Math.sin(a);
      g.lineWidth = i % 6 === 0 ? 8 : 3;
      g.beginPath(); g.moveTo(cx + c * r0, cy + s * r0); g.lineTo(cx + c * 224, cy + s * 224); g.stroke();
    }
    g.fillStyle = 'rgba(214,170,84,0.12)';
    g.beginPath(); g.moveTo(cx, cy); g.arc(cx, cy, 228, -1.25, -0.45); g.closePath(); g.fill();
    // scuffs and puddles
    for (let i = 0; i < 26; i++) {
      const x = wall + 40 + rnd() * (A.w - wall * 2 - 80), y = wall + 40 + rnd() * (A.h - wall * 2 - 80), r = 14 + rnd() * 40;
      g.fillStyle = wet ? 'rgba(150,200,210,' + (0.05 + rnd() * 0.09) + ')' : 'rgba(0,0,0,' + (0.04 + rnd() * 0.07) + ')';
      g.beginPath(); g.ellipse(x, y, r * 1.5, r * 0.8, rnd() * 3, 0, TAU); g.fill();
    }
    // the rift crack (its glow is animated separately)
    g.lineJoin = 'round'; g.lineCap = 'round';
    g.strokeStyle = '#0b0714'; g.lineWidth = 16;
    g.beginPath(); CRACK.forEach((p, i) => (i ? g.lineTo(p[0], p[1]) : g.moveTo(p[0], p[1]))); g.stroke();
    g.strokeStyle = '#2a1030'; g.lineWidth = 5;
    [[370, 470, 330, 560], [590, 492, 640, 590], [930, 452, 900, 360], [1150, 470, 1210, 390]].forEach((b) => { g.beginPath(); g.moveTo(b[0], b[1]); g.lineTo(b[2], b[3]); g.stroke(); });
    // walls: a lit top edge and a hard inner boundary line
    g.fillStyle = '#4d666a';
    g.fillRect(wall - 12, wall - 12, A.w - (wall - 12) * 2, 12); g.fillRect(wall - 12, A.h - wall, A.w - (wall - 12) * 2, 12);
    g.fillRect(wall - 12, wall - 12, 12, A.h - (wall - 12) * 2); g.fillRect(A.w - wall, wall - 12, 12, A.h - (wall - 12) * 2);
    g.fillStyle = 'rgba(0,0,0,0.3)';
    g.fillRect(wall, wall, A.w - wall * 2, 16);
    g.strokeStyle = 'rgba(244,236,216,0.75)'; g.lineWidth = 3; g.setLineDash([26, 14]);
    g.strokeRect(wall + 7, wall + 7, A.w - wall * 2 - 14, A.h - wall * 2 - 14);
    g.setLineDash([]);
    g.strokeStyle = '#ffc02e'; g.lineWidth = 6;
    const L = 46, m = wall + 7;
    [[m, m, 1, 1], [A.w - m, m, -1, 1], [m, A.h - m, 1, -1], [A.w - m, A.h - m, -1, -1]].forEach((c) => {
      g.beginPath(); g.moveTo(c[0] + c[2] * L, c[1]); g.lineTo(c[0], c[1]); g.lineTo(c[0], c[1] + c[3] * L); g.stroke();
    });
  }

  function drawRiftGlow() {
    const pulse = 0.5 + 0.5 * Math.sin(time * 1.7);
    ctx.lineJoin = 'round'; ctx.lineCap = 'round';
    ctx.strokeStyle = P.rift; ctx.globalAlpha = 0.25 + pulse * 0.2; ctx.lineWidth = 9;
    ctx.beginPath(); CRACK.forEach((p, i) => (i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]))); ctx.stroke();
    ctx.globalAlpha = 0.75; ctx.lineWidth = 2.5; ctx.strokeStyle = '#ffd9e8'; ctx.stroke();
    ctx.globalAlpha = 1;
  }

  /* ---- obstacles ------------------------------------------------------- */
  function drawObstacle(o) {
    if (o.type === 'pillar') {
      const h = 38;
      ctx.fillStyle = 'rgba(0,0,0,0.3)'; ell(o.x + 12, o.y + 10, o.r * 1.1, o.r * 0.8);
      ctx.fillStyle = '#3e5357'; circ(ctx, o.x, o.y, o.r); ctx.fill(); ctx.fillRect(o.x - o.r, o.y - h, o.r * 2, h);
      ctx.fillStyle = 'rgba(0,0,0,0.22)'; ctx.fillRect(o.x - o.r, o.y - h, o.r * 0.5, h);
      ctx.fillStyle = '#7d989b'; circ(ctx, o.x, o.y - h, o.r); ctx.fill();
      ctx.strokeStyle = '#5c777a'; ctx.lineWidth = 4; circ(ctx, o.x, o.y - h, o.r * 0.62); ctx.stroke();
    } else if (o.type === 'gnomon') {
      const h = 14;
      ctx.fillStyle = 'rgba(0,0,0,0.3)'; ell(o.x + 10, o.y + 8, o.r * 1.1, o.r * 0.8);
      ctx.fillStyle = '#6b5226'; circ(ctx, o.x, o.y, o.r); ctx.fill(); ctx.fillRect(o.x - o.r, o.y - h, o.r * 2, h);
      ctx.fillStyle = '#c79a45'; circ(ctx, o.x, o.y - h, o.r); ctx.fill();
      ctx.fillStyle = '#8b6a2c'; ctx.beginPath(); ctx.moveTo(o.x - 26, o.y - h + 14); ctx.lineTo(o.x + 30, o.y - h - 6); ctx.lineTo(o.x + 18, o.y - h - 62); ctx.closePath(); ctx.fill();
      ctx.fillStyle = '#f0c96a'; ctx.beginPath(); ctx.moveTo(o.x - 26, o.y - h + 14); ctx.lineTo(o.x + 18, o.y - h - 62); ctx.lineTo(o.x + 8, o.y - h - 58); ctx.closePath(); ctx.fill();
    } else {
      const h = 28;
      ctx.fillStyle = 'rgba(0,0,0,0.3)'; ctx.fillRect(o.x + 10, o.y + 8, o.w, o.h);
      ctx.fillStyle = '#5a3d22'; ctx.fillRect(o.x, o.y + o.h - h, o.w, h);
      ctx.fillStyle = '#a8763c'; ctx.fillRect(o.x, o.y - h, o.w, o.h);
      ctx.strokeStyle = '#5a3d22'; ctx.lineWidth = 4; ctx.strokeRect(o.x + 2, o.y - h + 2, o.w - 4, o.h - 4);
      ctx.beginPath(); ctx.moveTo(o.x + 4, o.y - h + 4); ctx.lineTo(o.x + o.w - 4, o.y - h + o.h - 4); ctx.stroke();
    }
  }

  /* ---- weapons and pickups --------------------------------------------- */
  function weaponIcon(c, icon, s) {
    c.lineCap = 'round'; c.lineJoin = 'round';
    if (icon === 'sword') {
      c.lineWidth = 3.4 * s; c.beginPath(); c.moveTo(-9 * s, 9 * s); c.lineTo(10 * s, -10 * s); c.stroke();
      c.lineWidth = 3 * s; c.beginPath(); c.moveTo(-9 * s, 2 * s); c.lineTo(-2 * s, 9 * s); c.stroke();
    } else if (icon === 'bow') {
      c.lineWidth = 3 * s; c.beginPath(); c.arc(-4 * s, 0, 11 * s, -1.15, 1.15); c.stroke();
      c.lineWidth = 1.4 * s; c.beginPath(); c.moveTo(0.5 * s, -10 * s); c.lineTo(0.5 * s, 10 * s); c.stroke();
      c.lineWidth = 2 * s; c.beginPath(); c.moveTo(-8 * s, 0); c.lineTo(11 * s, 0); c.stroke();
    } else if (icon === 'rifle') {
      c.lineWidth = 3.4 * s; c.beginPath(); c.moveTo(-11 * s, 3 * s); c.lineTo(12 * s, -5 * s); c.stroke();
      c.lineWidth = 5 * s; c.beginPath(); c.moveTo(-11 * s, 3 * s); c.lineTo(-5 * s, 4 * s); c.stroke();
      c.lineWidth = 2.4 * s; c.beginPath(); c.moveTo(-2 * s, 1 * s); c.lineTo(-3 * s, 7 * s); c.stroke();
    } else {
      c.lineWidth = 2.6 * s; rrect(c, -8 * s, -6 * s, 15 * s, 12 * s, 4 * s); c.stroke();
      c.beginPath(); c.moveTo(-3 * s, -6 * s); c.lineTo(-3 * s, 0); c.moveTo(2 * s, -6 * s); c.lineTo(2 * s, 0); c.stroke();
    }
  }
  RR.weaponIcon = weaponIcon;

  function drawPickup(k) {
    const bob = Math.sin(k.t * 3) * 3;
    ctx.fillStyle = 'rgba(0,0,0,0.3)'; ell(k.x, k.y + 10, 16, 7);
    if (k.kind === 'weapon') {
      ctx.fillStyle = 'rgba(12,23,28,0.85)'; circ(ctx, k.x, k.y - 6 + bob, 19); ctx.fill();
      ctx.strokeStyle = P.gold; ctx.lineWidth = 3; ctx.stroke();
      ctx.save(); ctx.translate(k.x, k.y - 6 + bob); ctx.strokeStyle = P.bone; weaponIcon(ctx, RR.WEAPONS[k.id].icon, 1); ctx.restore();
      ctx.strokeStyle = P.gold; ctx.globalAlpha = 0.35 + 0.25 * Math.sin(k.t * 4); ctx.lineWidth = 2; circ(ctx, k.x, k.y + 6, 26); ctx.stroke(); ctx.globalAlpha = 1;
    } else {
      const big = k.kind === 'medkit', r = big ? 15 : 10;
      ctx.fillStyle = P.bone; rrect(ctx, k.x - r, k.y - 8 - r + bob, r * 2, r * 2, 4); ctx.fill();
      ctx.fillStyle = '#17a36b'; ctx.fillRect(k.x - r * 0.6, k.y - 8 - r * 0.2 + bob, r * 1.2, r * 0.4); ctx.fillRect(k.x - r * 0.2, k.y - 8 - r * 0.6 + bob, r * 0.4, r * 1.2);
    }
  }

  function drawSupply(S) {
    if (S.state === 'marker') {
      const k = clamp(S.timer / 3.2, 0, 1);
      ctx.strokeStyle = P.gold; ctx.lineWidth = 4; ctx.setLineDash([12, 8]); circ(ctx, S.x, S.y, 46); ctx.stroke(); ctx.setLineDash([]);
      ctx.lineWidth = 6; ctx.beginPath(); ctx.arc(S.x, S.y, 56, -Math.PI / 2, -Math.PI / 2 + TAU * (1 - k)); ctx.stroke();
      ctx.fillStyle = 'rgba(0,0,0,' + (0.15 + 0.3 * (1 - k)) + ')'; ell(S.x, S.y, 12 + 26 * (1 - k), 8 + 16 * (1 - k));
      const fy = S.y - 30 - k * 520;
      if (k < 0.5) drawCrateBox(S.x, fy, 1);
    } else if (S.state === 'landed') drawCrateBox(S.x, S.y, 1);
    else if (S.state === 'open') { ctx.globalAlpha = 0.5; drawCrateBox(S.x, S.y, 0.55); ctx.globalAlpha = 1; }
  }
  function drawCrateBox(x, y, hgt) {
    const w = 52, d = 40, h = 30 * hgt;
    ctx.fillStyle = 'rgba(0,0,0,0.3)'; ctx.fillRect(x - w / 2 + 8, y - d / 2 + 8, w, d);
    ctx.fillStyle = '#6b4a1c'; ctx.fillRect(x - w / 2, y + d / 2 - h, w, h);
    ctx.fillStyle = '#d19a35'; ctx.fillRect(x - w / 2, y - d / 2 - h, w, d);
    ctx.fillStyle = '#0c171c'; ctx.fillRect(x - w / 2, y - 5 - h, w, 10); ctx.fillRect(x - 5, y - d / 2 - h, 10, d);
  }

  /* ---- fighters -------------------------------------------------------- */
  function drawHeldWeapon(f, icon, a, r, hands) {
    // local space: +x is the facing direction
    const W = a ? a.W : null;
    if (icon === 'sword') {
      const len = (W ? W.range : 96) - r * 0.25;
      let ang = 0.95;
      if (a) {
        const half = W.arc / 2, dir = a.idx % 2 ? -1 : 1;
        if (a.phase === 'w') ang = -half * dir - 0.25 * dir;
        else if (a.phase === 'a') {
          const k = clamp(a.t / a.ad, 0, 1);
          ang = (-half + k * W.arc) * dir;
          ctx.fillStyle = 'rgba(244,236,216,0.28)';
          ctx.beginPath(); ctx.moveTo(0, 0);
          ctx.arc(0, 0, len + 6, Math.min(-half * dir, ang), Math.max(-half * dir, ang)); ctx.closePath(); ctx.fill();
        } else ang = half * dir * (1 - 0.4 * clamp(a.t / a.rd, 0, 1));
      }
      const c = Math.cos(ang), s = Math.sin(ang), hx = c * r * 0.75, hy = s * r * 0.75;
      hands.rx = hx; hands.ry = hy;
      ctx.lineCap = 'round';
      ctx.strokeStyle = '#0c171c'; ctx.lineWidth = 8; ctx.beginPath(); ctx.moveTo(hx, hy); ctx.lineTo(c * len, s * len); ctx.stroke();
      ctx.strokeStyle = '#e9eef0'; ctx.lineWidth = 4.5; ctx.stroke();
      ctx.strokeStyle = P.gold; ctx.lineWidth = 5; ctx.beginPath(); ctx.moveTo(hx * 1.25 - s * 9, hy * 1.25 + c * 9); ctx.lineTo(hx * 1.25 + s * 9, hy * 1.25 - c * 9); ctx.stroke();
    } else if (icon === 'bow') {
      let pull = 0;
      if (a && a.phase === 'w') pull = clamp(a.t / a.wd, 0, 1);
      const bx = r * 1.05;
      hands.lx = bx; hands.ly = 0; hands.rx = bx - 6 - pull * r * 0.9; hands.ry = 0;
      ctx.lineCap = 'round';
      ctx.strokeStyle = '#7a4a1e'; ctx.lineWidth = 4.5; ctx.beginPath(); ctx.arc(bx - r * 0.7, 0, r * 0.95, -1.05, 1.05); ctx.stroke();
      const ex = bx - r * 0.7 + Math.cos(1.05) * r * 0.95, ey = Math.sin(1.05) * r * 0.95;
      ctx.strokeStyle = P.bone; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(ex, -ey); ctx.lineTo(hands.rx, 0); ctx.lineTo(ex, ey); ctx.stroke();
      if (pull > 0) { ctx.strokeStyle = P.bone; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.moveTo(hands.rx, 0); ctx.lineTo(hands.rx + r * 1.5, 0); ctx.stroke(); }
    } else if (icon === 'rifle') {
      const kick = a && a.phase === 'a' ? -5 : 0;
      hands.lx = r * 1.15 + kick; hands.ly = 2; hands.rx = r * 0.45 + kick; hands.ry = 5;
      ctx.lineCap = 'butt';
      ctx.strokeStyle = '#1b1410'; ctx.lineWidth = 7; ctx.beginPath(); ctx.moveTo(r * 0.1 + kick, 4); ctx.lineTo(r * 2.2 + kick, 2); ctx.stroke();
      ctx.strokeStyle = '#8a5a2b'; ctx.lineWidth = 8; ctx.beginPath(); ctx.moveTo(r * 0.05 + kick, 5); ctx.lineTo(r * 0.75 + kick, 4); ctx.stroke();
      if (a && a.phase === 'a') { ctx.fillStyle = P.gold; circ(ctx, r * 2.45, 2, 9); ctx.fill(); ctx.fillStyle = '#fff'; circ(ctx, r * 2.4, 2, 4.5); ctx.fill(); }
    }
  }

  const hands = { lx: 0, ly: 0, rx: 0, ry: 0 };
  function drawFighter(f, alphaMul) {
    const r = f.r, a = f.atk, isP = f.team === 'player', look = f.def.look;
    let alpha = alphaMul === undefined ? 1 : alphaMul;
    if (f.spawnT > 0) alpha *= 1 - f.spawnT / 0.9;
    if (f.state === 'dead') alpha *= clamp(f.deadT / 0.9, 0, 1);
    if (alpha <= 0.01) return;
    const body = f.flash > 0 ? '#ffffff' : isP ? P.player : P.looks[look], dk = isP ? P.playerDk : P.enemyDk;
    ctx.save();
    ctx.globalAlpha = alpha;
    ctx.fillStyle = 'rgba(0,0,0,0.3)'; ell(f.x + 5, f.y + 9, r * 1.05, r * 0.7);
    ctx.strokeStyle = isP ? P.player : P.enemy; ctx.lineWidth = 3;
    if (!isP) ctx.setLineDash([7, 5]);
    circ(ctx, f.x, f.y + 3, r + 6); ctx.stroke(); ctx.setLineDash([]);
    if (f.armorT > 0) { ctx.strokeStyle = P.gold; ctx.lineWidth = 4; ctx.globalAlpha = alpha * Math.min(1, f.armorT * 2); circ(ctx, f.x, f.y + 3, r + 11); ctx.stroke(); ctx.globalAlpha = alpha; }
    if (f.spawnT > 0) { ctx.strokeStyle = P.rift; ctx.lineWidth = 4; circ(ctx, f.x, f.y, r + 10 + f.spawnT * 40); ctx.stroke(); }
    ctx.translate(f.x, f.y - 5);
    if (f.state === 'dodge') ctx.globalAlpha = alpha * 0.6;
    ctx.rotate(f.face);
    if (f.state === 'dead') ctx.scale(1.15, 0.9);
    const sway = Math.sin(f.walk) * 4;
    // trailing accessory, gives each fighter a readable silhouette
    if (look === 'runner' || look === 'duelist') {
      ctx.fillStyle = look === 'runner' ? P.gold : P.bone;
      ctx.beginPath(); ctx.moveTo(-r * 0.3, -4); ctx.lineTo(-r * (look === 'runner' ? 1.5 : 1.7), sway * 1.6); ctx.lineTo(-r * 0.3, 4); ctx.closePath(); ctx.fill();
    } else if (look === 'archer') {
      ctx.fillStyle = dk; ctx.beginPath(); ctx.moveTo(0, -r * 0.5); ctx.lineTo(-r * 1.15, 0); ctx.lineTo(0, r * 0.5); ctx.closePath(); ctx.fill();
    }
    // hands
    hands.lx = r * 0.55 + sway; hands.ly = -r * 0.8; hands.rx = r * 0.55 - sway; hands.ry = r * 0.8;
    const W = RR.game.wepOf(f), icon = W.icon;
    let fistBig = 0;
    if (f.blocking) { hands.lx = r * 0.98; hands.ly = -r * 0.32; hands.rx = r * 0.98; hands.ry = r * 0.32; }
    if (icon === 'fist') {
      if (a) {
        let k;
        if (a.phase === 'w') k = -0.3 * clamp(a.t / a.wd, 0, 1);
        else if (a.phase === 'a') k = clamp(a.t / a.ad, 0, 1);
        else k = 1 - clamp(a.t / a.rd, 0, 1);
        const ext = r * 0.55 + k * (W.range - r * 0.7), right = a.idx !== 1;
        if (right) { hands.rx = ext; hands.ry = r * 0.25; } else { hands.lx = ext; hands.ly = -r * 0.25; }
        if (a.mv.heavy) fistBig = right ? 1 : 2;
        if (a.phase === 'a') {
          ctx.strokeStyle = 'rgba(244,236,216,0.45)'; ctx.lineWidth = r * 0.5; ctx.lineCap = 'round';
          ctx.beginPath(); ctx.moveTo(r * 0.5, right ? r * 0.25 : -r * 0.25); ctx.lineTo(ext, right ? r * 0.25 : -r * 0.25); ctx.stroke();
        }
      }
    } else drawHeldWeapon(f, icon, a, r, hands);
    // shoulders
    const sw = look === 'bruiser' ? 1.12 : 1;
    ctx.fillStyle = body; rrect(ctx, -r * 0.44, -r * 0.98 * sw, r * 0.88, r * 1.96 * sw, r * 0.42); ctx.fill();
    ctx.strokeStyle = dk; ctx.lineWidth = 2.5; ctx.stroke();
    if (look === 'bruiser') { ctx.fillStyle = dk; circ(ctx, 0, -r * 0.95, r * 0.36); ctx.fill(); circ(ctx, 0, r * 0.95, r * 0.36); ctx.fill(); }
    // fists
    ctx.fillStyle = f.flash > 0 ? '#fff' : P.bone; ctx.strokeStyle = '#0c171c'; ctx.lineWidth = 2;
    circ(ctx, hands.lx, hands.ly, r * (fistBig === 2 ? 0.42 : 0.3)); ctx.fill(); ctx.stroke();
    circ(ctx, hands.rx, hands.ry, r * (fistBig === 1 ? 0.42 : 0.3)); ctx.fill(); ctx.stroke();
    // head
    if (look === 'gunner') { ctx.fillStyle = dk; circ(ctx, r * 0.05, 0, r * 0.74); ctx.fill(); }
    ctx.fillStyle = f.flash > 0 ? '#fff' : look === 'bruiser' ? '#59666b' : P.bone;
    circ(ctx, r * 0.08, 0, r * 0.5); ctx.fill();
    ctx.strokeStyle = '#0c171c'; ctx.lineWidth = 2; ctx.stroke();
    ctx.fillStyle = '#0c171c'; ctx.beginPath(); ctx.arc(r * 0.08, 0, r * 0.5, -0.75, 0.75); ctx.closePath(); ctx.fill();
    if (f.blocking) { ctx.strokeStyle = P.bone; ctx.lineWidth = 5; ctx.lineCap = 'round'; ctx.beginPath(); ctx.arc(0, 0, r + 15, -1.05, 1.05); ctx.stroke(); }
    if (f.state === 'stagger') { ctx.strokeStyle = P.gold; ctx.lineWidth = 3; for (let i = 0; i < 3; i++) { const an = time * 9 + i * 2.1; ctx.beginPath(); ctx.arc(Math.cos(an) * r * 0.5, Math.sin(an) * r * 0.5, 4, 0, TAU); ctx.stroke(); } }
    ctx.restore();
  }
  RR.drawFighterIcon = function (canvas, id) {
    const c = canvas.getContext('2d'), keep = ctx, s = canvas.width / 96;
    ctx = c;
    c.setTransform(1, 0, 0, 1, 0, 0); c.clearRect(0, 0, canvas.width, canvas.height);
    c.scale(s, s);
    const def = RR.FIGHTERS[id];
    const f = { x: 44, y: 54, r: def.r * 1.05, face: -0.55, def, team: def.playable ? 'player' : 'enemy', atk: null, state: 'idle', flash: 0, spawnT: 0, walk: 1, blocking: false, deadT: 0, weapon: null, useFists: true };
    drawFighter(f, 1);
    ctx = keep;
  };
  RR.drawArenaMini = function (canvas, arenaId) {
    buildGround(arenaId, 'clear');
    const A = RR.ARENAS[arenaId], c = canvas.getContext('2d'), keep = ctx, s = canvas.width / A.w;
    ctx = c;
    c.setTransform(1, 0, 0, 1, 0, 0); c.clearRect(0, 0, canvas.width, canvas.height);
    c.scale(s, s);
    c.drawImage(ground, 0, 0, A.w, A.h);
    A.obstacles.slice().sort((a, b) => a.y - b.y).forEach(drawObstacle);
    ctx = keep;
  };

  /* ---- telegraphs: where an opponent is about to strike ----------------- */
  function drawTelegraphs(M) {
    for (const f of M.fighters) {
      const a = f.atk;
      if (f.team !== 'enemy' || !a || a.phase === 'r') continue;
      const W = a.W, k = a.phase === 'w' ? clamp(a.t / a.wd, 0, 1) : 1;
      if (W.kind === 'melee') {
        const R = W.range + 16, half = W.arc / 2;
        ctx.fillStyle = 'rgba(' + P.warn + ',' + (0.12 + 0.2 * k) + ')';
        ctx.beginPath(); ctx.moveTo(f.x, f.y); ctx.arc(f.x, f.y, R, f.face - half, f.face + half); ctx.closePath(); ctx.fill();
        ctx.fillStyle = 'rgba(' + P.warn + ',0.4)';
        ctx.beginPath(); ctx.moveTo(f.x, f.y); ctx.arc(f.x, f.y, R * k, f.face - half, f.face + half); ctx.closePath(); ctx.fill();
        ctx.strokeStyle = 'rgba(' + P.warn + ',0.95)'; ctx.lineWidth = 3; ctx.setLineDash([9, 6]);
        ctx.beginPath(); ctx.moveTo(f.x, f.y); ctx.arc(f.x, f.y, R, f.face - half, f.face + half); ctx.closePath(); ctx.stroke(); ctx.setLineDash([]);
      } else {
        const c = Math.cos(f.face), s = Math.sin(f.face);
        let len = 900;
        for (let d = 40; d <= 900; d += 40) { if (!RR.game.los(f.x, f.y, f.x + c * d, f.y + s * d)) { len = d - 20; break; } }
        const locked = a.phase === 'a' || a.wd - a.t < 0.24;
        ctx.strokeStyle = 'rgba(' + P.warn + ',' + (locked ? 1 : 0.35 + 0.4 * k) + ')';
        ctx.lineWidth = locked ? 7 : 2 + 3 * k;
        if (!locked) ctx.setLineDash([14, 10]);
        ctx.lineCap = 'butt';
        ctx.beginPath(); ctx.moveTo(f.x + c * f.r, f.y + s * f.r); ctx.lineTo(f.x + c * len, f.y + s * len); ctx.stroke(); ctx.setLineDash([]);
      }
    }
  }

  /* ---- world-space labels ---------------------------------------------- */
  function drawEnemyTags(M) {
    const p = M.player, vis = M.condDef.vision;
    ctx.textAlign = 'center';
    for (const f of M.fighters) {
      if (f.team !== 'enemy' || f.state === 'dead' || f.spawnT > 0.5) continue;
      if (vis && Math.hypot(f.x - p.x, f.y - p.y) > vis * 1.15) continue;
      const y = f.y - f.r - 34, w = 50;
      ctx.fillStyle = 'rgba(8,17,22,0.85)'; rrect(ctx, f.x - w / 2 - 2, y - 2, w + 4, 10, 3); ctx.fill();
      ctx.fillStyle = P.bone; ctx.fillRect(f.x - w / 2, y, w * clamp(f.hp / f.maxHp, 0, 1), 6);
      ctx.fillStyle = P.enemy; ctx.beginPath(); ctx.moveTo(f.x - 7, y - 14); ctx.lineTo(f.x + 7, y - 14); ctx.lineTo(f.x, y - 5); ctx.closePath(); ctx.fill();
      ctx.strokeStyle = '#081116'; ctx.lineWidth = 1.5; ctx.stroke();
      if (f.age < 3.2) {
        ctx.font = '900 15px ' + RR.fontDisplay; ctx.lineWidth = 4; ctx.strokeStyle = '#081116'; ctx.fillStyle = P.bone;
        const name = RR.t('fighter.' + f.id + '.name').toUpperCase();
        ctx.strokeText(name, f.x, y - 19); ctx.fillText(name, f.x, y - 19);
      }
    }
  }
  function drawTexts(M) {
    ctx.textAlign = 'center';
    for (const t of M.texts) {
      const k = t.life / t.max;
      ctx.globalAlpha = clamp(k * 2, 0, 1);
      const big = t.kind === 'good' || t.kind === 'bad';
      ctx.font = '900 ' + (big ? 24 : 20) + 'px ' + RR.fontDisplay;
      ctx.lineWidth = 5; ctx.strokeStyle = '#081116';
      ctx.fillStyle = t.kind === 'bad' ? P.enemy : t.kind === 'good' ? P.gold : t.kind === 'info' ? P.player : P.bone;
      ctx.strokeText(t.txt, t.x, t.y); ctx.fillText(t.txt, t.x, t.y);
    }
    ctx.globalAlpha = 1;
  }
  const PCOL = { spark: '#ffe9a8', hit: '#f4ecd8', dust: 'rgba(200,210,205,0.6)', heal: '#7ff0c0' };
  function drawParticles(M) {
    for (const q of M.particles) {
      ctx.globalAlpha = clamp(q.life / q.max, 0, 1);
      ctx.fillStyle = q.color === 'hurt' ? P.enemy : q.color === 'rift' ? P.rift : PCOL[q.color] || '#fff';
      ctx.fillRect(q.x - q.size / 2, q.y - q.size / 2, q.size, q.size);
    }
    ctx.globalAlpha = 1;
  }
  function drawProjectiles(M) {
    ctx.lineCap = 'round';
    for (const p of M.projectiles) {
      const c = Math.cos(p.a), s = Math.sin(p.a);
      if (p.kind === 'arrow') {
        ctx.strokeStyle = '#081116'; ctx.lineWidth = 6; ctx.beginPath(); ctx.moveTo(p.x - c * 30, p.y - s * 30); ctx.lineTo(p.x, p.y); ctx.stroke();
        ctx.strokeStyle = p.team === 'player' ? P.player : P.enemy; ctx.lineWidth = 3; ctx.stroke();
      } else {
        ctx.strokeStyle = p.team === 'player' ? P.player : P.enemy; ctx.globalAlpha = 0.45; ctx.lineWidth = 7;
        ctx.beginPath(); ctx.moveTo(p.x - c * 70, p.y - s * 70); ctx.lineTo(p.x, p.y); ctx.stroke();
        ctx.globalAlpha = 1; ctx.strokeStyle = '#fff'; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(p.x - c * 26, p.y - s * 26); ctx.lineTo(p.x, p.y); ctx.stroke();
      }
    }
  }

  /* ---- weather / lighting overlays (screen space) ----------------------- */
  const sx = (x, cam) => (x - cam.x) * zoom + cw / 2, sy = (y, cam) => (y - cam.y) * zoom + ch / 2;
  function drawFog(M, cam) {
    const p = M.player, x = sx(p.x, cam), y = sy(p.y, cam), v = M.condDef.vision * zoom;
    const g = ctx.createRadialGradient(x, y, v * 0.5, x, y, v * 1.2);
    g.addColorStop(0, 'rgba(188,203,202,0)'); g.addColorStop(0.6, 'rgba(188,203,202,0.72)'); g.addColorStop(1, 'rgba(188,203,202,0.95)');
    ctx.fillStyle = g; ctx.fillRect(0, 0, cw, ch);
  }
  function drawNight(M, cam) {
    const div = RR.settings.quality === 'low' ? 4 : 3;
    if (!dark) { dark = document.createElement('canvas'); dark.width = Math.ceil(cw / div); dark.height = Math.ceil(ch / div); dctx = dark.getContext('2d'); }
    const d = dctx, k = 1 / div;
    d.globalCompositeOperation = 'source-over';
    d.clearRect(0, 0, dark.width, dark.height);
    d.fillStyle = 'rgba(4,8,22,0.9)'; d.fillRect(0, 0, dark.width, dark.height);
    d.globalCompositeOperation = 'destination-out';
    const light = (wx, wy, r, a) => {
      const x = sx(wx, cam) * k, y = sy(wy, cam) * k, R = r * zoom * k;
      if (x < -R || y < -R || x > dark.width + R || y > dark.height + R) return;
      const g = d.createRadialGradient(x, y, R * 0.15, x, y, R);
      g.addColorStop(0, 'rgba(0,0,0,' + a + ')'); g.addColorStop(1, 'rgba(0,0,0,0)');
      d.fillStyle = g; d.beginPath(); d.arc(x, y, R, 0, TAU); d.fill();
    };
    light(M.player.x, M.player.y, 300, 1);
    light(M.arena.w / 2, M.arena.h / 2, 210, 0.45);
    for (const f of M.fighters) if (f.team === 'enemy' && f.state !== 'dead') light(f.x, f.y, 105, 0.75);
    for (const q of M.pickups) light(q.x, q.y, 62, 0.7);
    for (const q of M.projectiles) light(q.x, q.y, 60, 0.8);
    if (M.supply && M.supply.state !== 'wait' && M.supply.state !== 'open') light(M.supply.x, M.supply.y, 110, 0.8);
    ctx.drawImage(dark, 0, 0, cw, ch);
  }
  function drawRain() {
    const n = RR.settings.quality === 'low' ? 28 : RR.settings.quality === 'med' ? 70 : 130;
    ctx.strokeStyle = 'rgba(200,225,235,0.42)'; ctx.lineWidth = Math.max(1, 1.4 * scale); ctx.lineCap = 'butt';
    ctx.beginPath();
    const len = 22 * scale, vx = -260 * scale, vy = 1150 * scale;
    for (let i = 0; i < n; i++) {
      const x = (((i * 197.3 + time * vx * (0.8 + (i % 5) * 0.08)) % cw) + cw) % cw, y = ((i * 91.7 + time * vy * (0.8 + (i % 7) * 0.06)) % ch);
      ctx.moveTo(x, y); ctx.lineTo(x - len * 0.23, y + len);
    }
    ctx.stroke();
    ctx.fillStyle = 'rgba(20,40,60,0.16)'; ctx.fillRect(0, 0, cw, ch);
  }
  function drawEdgeArrows(M, cam) {
    const p = M.player, vis = M.condDef.vision, m = 26 * scale;
    for (const f of M.fighters) {
      if (f.team !== 'enemy' || f.state === 'dead') continue;
      if (vis && Math.hypot(f.x - p.x, f.y - p.y) > vis * 1.6) continue;
      const x = sx(f.x, cam), y = sy(f.y, cam);
      if (x > 0 && x < cw && y > 0 && y < ch) continue;
      const cx = clamp(x, m, cw - m), cy = clamp(y, m, ch - m), a = Math.atan2(y - cy, x - cx);
      ctx.save(); ctx.translate(cx, cy); ctx.rotate(a); ctx.scale(scale, scale);
      ctx.fillStyle = P.enemy; ctx.strokeStyle = '#081116'; ctx.lineWidth = 2.5;
      ctx.beginPath(); ctx.moveTo(14, 0); ctx.lineTo(-8, -11); ctx.lineTo(-3, 0); ctx.lineTo(-8, 11); ctx.closePath(); ctx.fill(); ctx.stroke();
      ctx.restore();
    }
    for (const q of M.pickups) {
      if (q.kind === 'health') continue;
      const x = sx(q.x, cam), y = sy(q.y, cam);
      if (x > 0 && x < cw && y > 0 && y < ch) continue;
      if (vis && Math.hypot(q.x - p.x, q.y - p.y) > vis * 1.6) continue;
      const cx = clamp(x, m, cw - m), cy = clamp(y, m, ch - m);
      ctx.fillStyle = P.gold; ctx.strokeStyle = '#081116'; ctx.lineWidth = 2 * scale;
      ctx.beginPath(); ctx.moveTo(cx, cy - 8 * scale); ctx.lineTo(cx + 8 * scale, cy); ctx.lineTo(cx, cy + 8 * scale); ctx.lineTo(cx - 8 * scale, cy); ctx.closePath(); ctx.fill(); ctx.stroke();
    }
  }

  /* ---- frame ----------------------------------------------------------- */
  const sortList = [];
  function drawWorld(M, cam, shake) {
    const A = M ? M.arena : RR.ARENAS.sundial;
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.fillStyle = '#081116'; ctx.fillRect(0, 0, cw, ch);
    let ox = 0, oy = 0;
    if (shake > 0 && RR.settings.shake) { ox = (Math.random() - 0.5) * shake * scale; oy = (Math.random() - 0.5) * shake * scale; }
    ctx.setTransform(zoom, 0, 0, zoom, cw / 2 - cam.x * zoom + ox, ch / 2 - cam.y * zoom + oy);
    ctx.drawImage(ground, 0, 0, A.w, A.h);
    drawRiftGlow();
    if (M) {
      if (M.supply && M.supply.state !== 'wait') drawSupply(M.supply);
      for (const k of M.pickups) drawPickup(k);
    }
    sortList.length = 0;
    for (const o of A.obstacles) sortList.push({ y: o.r ? o.y : o.y + o.h, o });
    if (M) for (const f of M.fighters) sortList.push({ y: f.y, f });
    sortList.sort((a, b) => a.y - b.y);
    for (const s of sortList) { if (s.o) drawObstacle(s.o); else drawFighter(s.f); }
    if (M) { drawProjectiles(M); drawParticles(M); }
  }

  function frame(dt) {
    if (!ctx) return;
    time += dt;
    const M = RR.game.M;
    P = RR.settings.colorblind ? PALS.cb : PALS.normal;
    if (M) {
      buildGround(M.arenaId, M.cond);
      drawWorld(M, M.cam, M.shake);
      const worldT = ctx.getTransform();
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      if (M.cond === 'rain') drawRain();
      if (M.cond === 'night') drawNight(M, M.cam);
      if (M.cond === 'fog') drawFog(M, M.cam);
      ctx.setTransform(worldT);
      drawTelegraphs(M);
      drawEnemyTags(M);
      drawTexts(M);
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      drawEdgeArrows(M, M.cam);
      const p = M.player;
      if (p.hp > 0 && p.hp < p.maxHp * 0.3) {
        const a = 0.18 + 0.1 * Math.sin(time * 6), b = Math.min(cw, ch) * 0.06;
        ctx.strokeStyle = 'rgba(' + P.warn + ',' + a + ')'; ctx.lineWidth = b; ctx.strokeRect(b / 2, b / 2, cw - b, ch - b);
      }
    } else {
      // menu backdrop: slow drift over the empty yard
      buildGround('sundial', 'clear');
      const A = RR.ARENAS.sundial;
      const cam = { x: A.w / 2 + Math.cos(time * 0.11) * 260, y: A.h / 2 + Math.sin(time * 0.17) * 150 };
      drawWorld(null, cam, 0);
      ctx.setTransform(1, 0, 0, 1, 0, 0);
    }
  }

  RR.render = {
    init(canvas) {
      cv = canvas;
      ctx = cv.getContext('2d', { alpha: false });
      resize();
      window.addEventListener('resize', resize);
      RR.onSetting((k) => { if (k === 'quality' || k === '*') { ground = null; groundKey = ''; resize(); } });
    },
    resize,
    frame,
    get info() { return { cw, ch, zoom, scale }; },
  };
})();
