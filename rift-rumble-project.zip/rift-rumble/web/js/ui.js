/* Rift Rumble — menus, HUD, hints, subtitles. All text comes from RR.t(). */
(function () {
  const RR = (window.RR = window.RR || {});
  const $ = (id) => document.getElementById(id);
  const el = (tag, cls, text) => {
    const e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text !== undefined) e.textContent = text;
    return e;
  };
  const SCREENS = ['menu', 'fighter', 'arena', 'howto', 'packs', 'settings', 'pause', 'results'];
  const stack = [];
  let current = 'menu';
  const hud = {};
  let bannerT = 0, subT = 0, toastT = 0, hint = null, fpsAcc = 0, fpsN = 0;

  /* ---- navigation ------------------------------------------------------ */
  function show(name) {
    current = name;
    SCREENS.forEach((s) => { $('s-' + s).hidden = s !== name; });
    if (name === 'menu') refreshMenu();
    if (name === 'settings') buildSettings();
    if (name) {
      const first = $('s-' + name).querySelector('.btn.big, [data-back]');
      if (first && !RR.input.touchMode) first.focus({ preventScroll: true });
    }
  }
  function go(name) { stack.push(current); RR.audio.sfx('ui'); show(name); }
  function back() {
    RR.audio.sfx('uiback');
    const prev = stack.pop();
    show(prev || 'menu');
  }
  function hideScreens() { current = ''; SCREENS.forEach((s) => { $('s-' + s).hidden = true; }); }

  function refreshMenu() {
    const b = $('menu-best');
    b.hidden = !(RR.save.best > 0);
    b.textContent = RR.t('menu.best', { n: RR.save.best });
  }

  /* ---- generic controls ------------------------------------------------ */
  function seg(container, key, opts, onChange) {
    container.textContent = '';
    opts.forEach(([val, labelKey, raw]) => {
      const b = el('button', '', raw || RR.t(labelKey));
      b.type = 'button';
      b.id = 'seg-' + key + '-' + val;
      b.setAttribute('aria-pressed', String(RR.settings[key] === val));
      b.addEventListener('click', () => {
        RR.setSetting(key, val);
        RR.audio.sfx('ui');
        container.querySelectorAll('button').forEach((x) => x.setAttribute('aria-pressed', String(x === b)));
        if (onChange) onChange(val);
      });
      container.appendChild(b);
    });
  }

  /* ---- settings screen (built from a schema) ---------------------------- */
  const pct = (v) => Math.round(v * 100) + '%';
  const SCHEMA = [
    ['set.game', [
      { k: 'language', label: 'set.language', type: 'lang' },
      { k: 'hints', label: 'set.hints', type: 'tog' },
    ]],
    ['set.controls', [
      { k: 'layout', label: 'set.layout', type: 'seg', opts: [['right', 'layout.right'], ['left', 'layout.left']] },
      { k: 'touch', label: 'set.touch', type: 'seg', opts: [['auto', 'touch.auto'], ['always', 'touch.always']] },
      { k: 'cam', label: 'set.cam', type: 'range', min: 0.5, max: 1.5, step: 0.1, fmt: (v) => v.toFixed(1) + '×' },
      { k: 'vibrate', label: 'set.vibrate', type: 'tog' },
    ]],
    ['set.audio', [
      { k: 'master', label: 'set.master', type: 'range', min: 0, max: 1, step: 0.05, fmt: pct },
      { k: 'sfx', label: 'set.sfx', type: 'range', min: 0, max: 1, step: 0.05, fmt: pct },
      { k: 'music', label: 'set.music', type: 'range', min: 0, max: 1, step: 0.05, fmt: pct },
      { k: 'voice', label: 'set.voice', type: 'tog', note: 'set.voice.note' },
      { k: 'subs', label: 'set.subs', type: 'tog' },
    ]],
    ['set.graphics', [
      { k: 'quality', label: 'set.quality', type: 'seg', opts: [['low', 'q.low'], ['med', 'q.med'], ['high', 'q.high']], note: 'set.quality.note' },
      { k: 'fps30', label: 'set.fps30', type: 'tog' },
      { k: 'showFps', label: 'set.showfps', type: 'tog' },
    ]],
    ['set.access', [
      { k: 'uiScale', label: 'set.uiscale', type: 'range', min: 0.8, max: 1.3, step: 0.05, fmt: pct },
      { k: 'colorblind', label: 'set.colorblind', type: 'tog', note: 'set.colorblind.note' },
      { k: 'shake', label: 'set.shake', type: 'tog' },
    ]],
  ];

  function buildSettings() {
    const root = $('settings');
    const scroll = root.parentElement.scrollTop;
    root.textContent = '';
    SCHEMA.forEach(([titleKey, items]) => {
      const g = el('div', 'set-group');
      g.appendChild(el('h3', '', RR.t(titleKey)));
      items.forEach((it) => {
        const row = el('div', 'row');
        const lab = el(it.type === 'range' ? 'label' : 'div', 'lab', RR.t(it.label));
        if (it.note) lab.appendChild(el('small', '', RR.t(it.note)));
        row.appendChild(lab);
        const id = 'set-' + it.k;
        if (it.type === 'tog') {
          const b = el('button', 'tog');
          b.type = 'button'; b.id = id;
          b.setAttribute('role', 'switch');
          b.setAttribute('aria-label', RR.t(it.label));
          const paint = () => { const on = !!RR.settings[it.k]; b.setAttribute('aria-checked', String(on)); b.textContent = RR.t(on ? 'ui.on' : 'ui.off'); };
          paint();
          b.addEventListener('click', () => { RR.setSetting(it.k, !RR.settings[it.k]); RR.audio.sfx('ui'); paint(); });
          row.appendChild(b);
        } else if (it.type === 'range') {
          const wrap = el('div', 'rng'), inp = el('input'), out = el('output');
          inp.type = 'range'; inp.id = id; inp.min = it.min; inp.max = it.max; inp.step = it.step; inp.value = RR.settings[it.k];
          lab.htmlFor = id;
          out.textContent = it.fmt(RR.settings[it.k]);
          inp.addEventListener('input', () => { const v = parseFloat(inp.value); RR.setSetting(it.k, v); out.textContent = it.fmt(v); });
          inp.addEventListener('change', () => RR.audio.sfx('ui'));
          wrap.appendChild(inp); wrap.appendChild(out); row.appendChild(wrap);
        } else {
          const s = el('div', 'seg');
          s.setAttribute('role', 'group');
          s.setAttribute('aria-label', RR.t(it.label));
          const opts = it.type === 'lang'
            ? Object.keys(RR.LOCALES).filter((c) => c !== 'zz' || RR.locale === 'zz').map((c) => [c, null, RR.LOCALES[c]._name])
            : it.opts;
          seg(s, it.k, opts);
          row.appendChild(s);
        }
        g.appendChild(row);
      });
      root.appendChild(g);
    });
    const g = el('div', 'set-group');
    const r = el('button', 'reset', RR.t('set.reset'));
    r.type = 'button'; r.id = 'set-reset';
    r.addEventListener('click', () => { RR.resetSettings(); buildSettings(); toast(RR.t('set.reset.done')); });
    g.appendChild(r);
    root.appendChild(g);
    const about = el('div', 'set-group about');
    about.appendChild(el('h3', '', RR.t('set.about')));
    about.appendChild(el('p', '', RR.t('about.version', { v: RR.version })));
    about.appendChild(el('p', '', RR.t('about.privacy')));
    about.appendChild(el('p', '', RR.t('about.credits')));
    root.appendChild(about);
    root.parentElement.scrollTop = scroll;
  }

  function applySettings(key) {
    const s = RR.settings, root = $('rr');
    root.style.setProperty('--ui', s.uiScale);
    root.classList.toggle('lefty', s.layout === 'left');
    root.classList.toggle('cb', s.colorblind);
    $('fps').hidden = !s.showFps;
    RR.audio.applyVolumes();
    if (!s.voice) RR.audio.hush();
    if (key === 'language' || key === '*') {
      RR.locale = RR.LOCALES[s.language] ? s.language : 'en';
      document.documentElement.lang = RR.locale === 'zz' ? 'en' : RR.locale;
      RR.applyI18n();
      buildStatic();
      if (current === 'settings') buildSettings();
      if (current === 'menu') refreshMenu();
    }
    if (key === 'uiScale') RR.render.resize();
  }

  /* ---- static, data-driven screens ------------------------------------- */
  function buildStatic() {
    // fighter roster: playable fighters, then locked slots for future packs
    const roster = $('roster');
    roster.textContent = '';
    Object.keys(RR.FIGHTERS).filter((id) => RR.FIGHTERS[id].playable).forEach((id) => {
      const def = RR.FIGHTERS[id], card = el('div', 'fcard sel'), cv = el('canvas'), fi = el('div', 'fi');
      cv.width = cv.height = 192;
      RR.drawFighterIcon(cv, id);
      fi.appendChild(el('div', 'role', RR.t('fighter.' + id + '.role')));
      fi.appendChild(el('h3', '', RR.t('fighter.' + id + '.name')));
      fi.appendChild(el('p', '', RR.t('fighter.' + id + '.desc')));
      const st = el('div', 'stats');
      ['power', 'speed', 'guard'].forEach((k) => {
        st.appendChild(el('span', '', RR.t('stat.' + k)));
        const pips = el('span', 'pips');
        for (let i = 0; i < 5; i++) pips.appendChild(el('i', i < def.stats[k] ? 'on' : ''));
        st.appendChild(pips);
      });
      fi.appendChild(st);
      card.appendChild(cv); card.appendChild(fi); roster.appendChild(card);
    });
    for (let i = 0; i < RR.PLANNED_FIGHTER_SLOTS; i++) {
      const c = el('div', 'fcard locked');
      c.appendChild(el('div', 'q', '?'));
      c.appendChild(el('div', '', RR.t('fighter.locked')));
      c.appendChild(el('small', '', RR.t('fighter.locked.note')));
      roster.appendChild(c);
    }
    const foes = $('foes');
    foes.textContent = '';
    RR.OPPONENTS.forEach((id) => {
      const f = el('div', 'foe'), cv = el('canvas'), d = el('div');
      cv.width = cv.height = 96;
      RR.drawFighterIcon(cv, id);
      d.appendChild(el('b', '', RR.t('fighter.' + id + '.name')));
      d.appendChild(el('small', '', RR.t('fighter.' + id + '.role')));
      f.appendChild(cv); f.appendChild(d); foes.appendChild(f);
    });
    // match setup
    RR.drawArenaMini($('arena-mini'), 'sundial');
    seg($('seg-cond'), 'cond', [['random', 'cond.random']].concat(RR.CONDITION_IDS.map((c) => [c, 'cond.' + c])));
    seg($('seg-supply'), 'supply', [['random', 'supply.random'], ['on', 'supply.on'], ['off', 'supply.off']]);
    seg($('seg-diff'), 'diff', [['easy', 'diff.easy'], ['normal', 'diff.normal'], ['hard', 'diff.hard']]);
    const pa = $('planned-arenas');
    pa.textContent = '';
    RR.PLANNED_ARENAS.forEach((a) => pa.appendChild(el('span', '', RR.t('arena.' + a.id + '.name'))));
    // content packs
    const packs = $('packs');
    packs.textContent = '';
    RR.PACKS.forEach((p) => {
      const c = el('div', 'pack' + (p.status === 'installed' ? ' installed' : ''));
      c.appendChild(el('span', 'pill', RR.t(p.status === 'installed' ? 'packs.installed' : 'packs.planned')));
      c.appendChild(el('h3', '', RR.t('pack.' + p.id + '.name')));
      c.appendChild(el('p', '', RR.t('pack.' + p.id + '.desc')));
      packs.appendChild(c);
    });
  }

  /* ---- toasts, banners, subtitles --------------------------------------- */
  function toast(text) { const t = $('toast'); t.textContent = text; t.hidden = false; toastT = 1.8; }
  function banner(text, sub, big) {
    const b = $('banner');
    $('banner-main').textContent = text;
    $('banner-sub').textContent = sub || '';
    b.classList.toggle('big', !!big);
    b.hidden = true; void b.offsetWidth; b.hidden = false;
    $('hud').classList.add('has-banner');
    bannerT = big ? 1.1 : 2.0;
  }
  function subtitle(speaker, lineKey) {
    const who = speaker === 'ann' ? RR.t('speaker.ann') : RR.t('fighter.' + speaker + '.name');
    const line = RR.t(lineKey);
    if (RR.settings.subs) {
      $('sub-who').textContent = who;
      $('sub-line').textContent = line;
      $('subtitle').hidden = false;
      subT = 2.6;
    }
    RR.audio.speak(line);
  }

  /* ---- first-match hints ------------------------------------------------ */
  const HINTS = [
    { key: 'move', done: (M) => M.stats.moved > 150, max: 30 },
    { key: 'attack', done: (M) => M.stats.attacks >= 3, max: 20 },
    { key: 'block', wait: (M) => M.spawned > 0, done: (M) => M.stats.blocks + M.stats.parries >= 1, max: 11 },
    { key: 'dodge', done: (M) => M.stats.dodges >= 1, max: 9 },
    { key: 'weapon', done: (M) => M.stats.pickups >= 1, max: 11 },
  ];
  function updateHints(M, dt) {
    if (!hint) return;
    const box = $('hint');
    if (hint.i >= HINTS.length) {
      hint.t -= dt;
      if (hint.t <= 0) { box.hidden = true; hint = null; }
      return;
    }
    const h = HINTS[hint.i];
    if (h.wait && !h.wait(M)) { box.hidden = true; return; }
    const text = RR.t('hint.' + h.key + (RR.input.touchMode ? '.touch' : '.keys'));
    if (box.hidden || box.textContent !== text) { box.textContent = text; box.hidden = false; }
    hint.t += dt;
    if (h.done(M) || hint.t > h.max) {
      hint.i++; hint.t = 0;
      if (hint.i >= HINTS.length) {
        box.textContent = RR.t('hint.done');
        hint.t = 2.6;
        RR.setSetting('hints', false);
      }
    }
  }

  /* ---- match HUD --------------------------------------------------------- */
  function condChips(M, parent, rich) {
    parent.textContent = '';
    const add = (name, desc) => {
      const c = el('span', 'chip');
      if (rich) { c.appendChild(el('b', '', name)); if (desc) c.appendChild(document.createTextNode(' · ' + desc)); } else c.textContent = name;
      parent.appendChild(c);
    };
    add(RR.t('cond.' + M.cond), rich ? RR.t('cond.' + M.cond + '.desc') : '');
    if (M.supply) add(RR.t('cond.supply'), rich ? RR.t('cond.supply.desc') : '');
    if (rich) add(RR.t('intro.weapons'), M.weaponSet.map((w) => RR.t('weapon.' + w)).join(', '));
    add(RR.t('diff.' + M.diffId), '');
  }

  function matchStart(M) {
    hideScreens();
    $('hud').hidden = false;
    $('hint').hidden = true; $('banner').hidden = true; $('subtitle').hidden = true;
    $('hud').classList.remove('has-banner'); bannerT = 0; subT = 0;
    $('hud').classList.remove('ended');
    $('touch').hidden = false; $('btn-pause').hidden = false;
    $('hud-name').textContent = RR.t('fighter.' + M.player.id + '.name');
    $('obj-conds').textContent = [RR.t('cond.' + M.cond)].concat(M.supply ? [RR.t('cond.supply')] : []).join(' · ');
    $('card-hero').textContent = RR.t('fighter.' + M.player.id + '.name');
    const foes = $('card-foes');
    foes.textContent = '';
    M.lineup.forEach((id) => foes.appendChild(el('div', '', RR.t('fighter.' + id + '.name'))));
    condChips(M, $('card-chips'), true);
    $('card').hidden = false;
    for (const k in hud) delete hud[k];
    hint = M.hints ? { i: 0, t: 0 } : null;
    RR.audio.music('fight');
    RR.audio.rain(M.cond === 'rain');
  }

  function set(id, prop, val) {
    const key = id + prop;
    if (hud[key] === val) return;
    hud[key] = val;
    const e = $(id);
    if (prop === 'text') e.textContent = val;
    else if (prop === 'hidden') e.hidden = val;
    else if (prop === 'scale') e.style.transform = 'scaleX(' + val + ')';
    else if (prop === 'now') e.setAttribute('aria-valuenow', val);
    else e.classList.toggle(prop, val);
  }

  function frame(dt) {
    const M = RR.game.M;
    if (toastT > 0) { toastT -= dt; if (toastT <= 0) $('toast').hidden = true; }
    if (!M) return;
    // drain simulation events
    const ev = RR.game.events;
    for (let i = 0; i < ev.length; i++) {
      const e = ev[i];
      if (e.type === 'banner') banner(RR.t(e.key, e.vars), e.sub, e.big);
      else if (e.type === 'bark') subtitle(e.speaker, e.lineKey);
      else if (e.type === 'ending') { $('touch').hidden = true; $('btn-pause').hidden = true; $('hint').hidden = true; if (hint && hint.i >= 2) RR.setSetting('hints', false); hint = null; RR.input.reset(); RR.audio.music('off'); RR.audio.rain(false); RR.audio.sfx(e.result === 'win' ? 'win' : 'lose'); }
      else if (e.type === 'over') showResults(M);
    }
    ev.length = 0;
    if (M.phase !== 'intro' && !$('card').hidden) $('card').hidden = true;
    if (bannerT > 0) { bannerT -= dt; if (bannerT <= 0) { $('banner').hidden = true; $('hud').classList.remove('has-banner'); } }
    if (subT > 0) { subT -= dt; if (subT <= 0) $('subtitle').hidden = true; }
    const p = M.player, hp = Math.max(0, Math.ceil(p.hp));
    set('hp-fill', 'scale', (Math.max(0, p.hp) / p.maxHp).toFixed(3));
    set('hp-num', 'text', String(hp));
    set('hp-track', 'now', String(hp));
    const low = p.hp > 0 && p.hp < p.maxHp * 0.3;
    set('hp-low', 'hidden', !low);
    if (hud.lowCls !== low) { hud.lowCls = low; $('hp-fill').parentElement.parentElement.classList.toggle('low', low); }
    set('st-fill', 'scale', (p.st / p.maxSt).toFixed(2));
    set('st-track', 'now', String(Math.round(p.st)));
    set('obj-count', 'text', M.defeated + '/' + M.lineup.length);
    const sec = Math.floor(M.t);
    set('obj-time', 'text', Math.floor(sec / 60) + ':' + String(sec % 60).padStart(2, '0'));
    const wid = p.weapon && !p.useFists ? p.weapon.id : 'fists';
    if (hud.wid !== wid) {
      hud.wid = wid;
      $('w-name').textContent = RR.t('weapon.' + wid);
      const c = $('w-icon').getContext('2d');
      c.setTransform(1, 0, 0, 1, 0, 0); c.clearRect(0, 0, 44, 44); c.translate(22, 22); c.strokeStyle = '#f4ecd8';
      RR.weaponIcon(c, RR.WEAPONS[wid].icon, 1.25);
    }
    set('w-uses', 'text', wid === 'fists' ? (p.weapon ? '(' + RR.t('weapon.' + p.weapon.id) + ' ' + p.weapon.uses + ')' : '') : '× ' + p.weapon.uses);
    set('swap-label', 'text', RR.t(M.nearTake ? 'btn.take' : 'btn.swap'));
    set('btn-swap', 'take', !!M.nearTake);
    set('btn-swap', 'off', !M.nearTake && !p.weapon);
    if (M.phase === 'fight') updateHints(M, dt);
    if (RR.settings.showFps) {
      fpsAcc += dt; fpsN++;
      if (fpsAcc >= 0.5) { $('fps').textContent = RR.t('hud.fps', { n: Math.round(fpsN / fpsAcc) }); fpsAcc = 0; fpsN = 0; }
    }
  }

  /* ---- results ---------------------------------------------------------- */
  function showResults(M) {
    const win = M.result === 'win', s = M.stats, root = $('s-results');
    root.classList.toggle('win', win); root.classList.toggle('lose', !win);
    $('res-title').textContent = RR.t(win ? 'res.victory' : 'res.defeat');
    const stars = $('res-stars');
    stars.textContent = '';
    stars.setAttribute('aria-label', RR.t('res.stars', { n: M.stars }));
    for (let i = 0; i < 3; i++) stars.appendChild(el('i', i < M.stars ? 'on' : ''));
    $('res-score').textContent = String(M.score);
    const isBest = M.score > RR.save.best;
    if (isBest) RR.save.best = M.score;
    RR.save.plays++;
    RR.persist();
    $('res-best').textContent = isBest ? RR.t('res.newbest') : RR.t('res.best', { n: RR.save.best });
    condChips(M, $('res-conds'), false);
    const dl = $('res-stats');
    dl.textContent = '';
    const sec = Math.floor(M.t);
    [
      ['res.time', Math.floor(sec / 60) + ':' + String(sec % 60).padStart(2, '0')],
      ['res.defeated', M.defeated + '/' + M.lineup.length],
      ['res.dealt', Math.round(s.dealt)],
      ['res.taken', Math.round(s.taken)],
      ['res.accuracy', s.attacks ? Math.round((s.hits / s.attacks) * 100) + '%' : '0%'],
      ['res.blocks', s.blocks],
      ['res.parries', s.parries],
    ].forEach(([k, v]) => { dl.appendChild(el('dt', '', RR.t(k))); dl.appendChild(el('dd', '', String(v))); });
    $('hud').hidden = true;
    stack.length = 0;
    show('results');
    RR.app.onMatchOver();
  }

  RR.ui = {
    init() {
      RR.applyI18n();
      buildStatic();
      applySettings('*');
      RR.onSetting(applySettings);
      document.querySelectorAll('[data-go]').forEach((b) => b.addEventListener('click', () => go(b.getAttribute('data-go'))));
      document.querySelectorAll('[data-back]').forEach((b) => b.addEventListener('click', () => RR.ui.back()));
      $('a-fight').addEventListener('click', () => RR.app.startMatch());
      $('btn-pause').addEventListener('click', () => RR.app.pause());
      $('p-resume').addEventListener('click', () => RR.app.resume());
      $('p-restart').addEventListener('click', () => RR.app.startMatch());
      $('p-settings').addEventListener('click', () => go('settings'));
      $('p-quit').addEventListener('click', () => RR.app.quit());
      $('r-rematch').addEventListener('click', () => RR.app.startMatch());
      $('r-setup').addEventListener('click', () => { stack.length = 0; stack.push('menu'); RR.audio.sfx('ui'); show('arena'); });
      $('r-menu').addEventListener('click', () => RR.app.quit());
      // any first interaction unlocks audio
      const unlock = () => { if (RR.audio.init()) { if (!RR.app.inMatch) RR.audio.music('menu'); } };
      window.addEventListener('pointerdown', unlock);
      window.addEventListener('keydown', unlock);
      show('menu');
    },
    show, go, hideScreens, matchStart, frame, toast,
    back() {
      if (current === 'pause') { RR.app.resume(); return; }
      back();
    },
    get current() { return current; },
    clearStack() { stack.length = 0; },
  };
})();
