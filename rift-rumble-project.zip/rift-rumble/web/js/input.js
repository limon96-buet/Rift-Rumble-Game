/* Rift Rumble — input: keyboard plus on-screen touch stick and buttons. */
(function () {
  const RR = (window.RR = window.RR || {});
  const keys = new Set();
  const st = { mx: 0, my: 0, attackPressed: false, block: false, dodgePressed: false, swapPressed: false };
  const stick = { id: null, ox: 0, oy: 0, x: 0, y: 0 };
  let touchBlock = false, pausePressed = false, coarse = false, sawTouch = false;

  const MOVE = {
    KeyW: [0, -1], ArrowUp: [0, -1], KeyS: [0, 1], ArrowDown: [0, 1],
    KeyA: [-1, 0], ArrowLeft: [-1, 0], KeyD: [1, 0], ArrowRight: [1, 0],
  };
  const GAME_KEYS = new Set(['Space', 'KeyJ', 'KeyK', 'KeyL', 'KeyQ', 'ShiftLeft', 'ShiftRight', ...Object.keys(MOVE)]);

  function refreshTouchVisibility() {
    const on = RR.settings.touch === 'always' || coarse || sawTouch;
    document.getElementById('rr').classList.toggle('touch-on', on);
    RR.input.touchMode = on;
  }

  function onKeyDown(e) {
    if (e.target && /INPUT|SELECT|TEXTAREA/.test(e.target.tagName)) return;
    if (e.code === 'Escape' || e.code === 'KeyP') { if (!e.repeat) pausePressed = true; e.preventDefault(); return; }
    if (!RR.app || !RR.app.inMatch) return;
    if (GAME_KEYS.has(e.code)) e.preventDefault();
    if (e.repeat) return;
    keys.add(e.code);
    if (e.code === 'KeyJ' || e.code === 'Space') st.attackPressed = true;
    else if (e.code === 'KeyL') st.dodgePressed = true;
    else if (e.code === 'KeyQ') st.swapPressed = true;
    if (sawTouch && !coarse && RR.settings.touch !== 'always') { sawTouch = false; refreshTouchVisibility(); }
  }
  function onKeyUp(e) { keys.delete(e.code); }

  function bindButton(id, down, up) {
    const el = document.getElementById(id);
    el.addEventListener('pointerdown', (e) => {
      e.preventDefault();
      noteTouch(e);
      try { el.setPointerCapture(e.pointerId); } catch (err) { /* ignore */ }
      el.classList.add('down');
      down();
    });
    const release = () => { el.classList.remove('down'); if (up) up(); };
    el.addEventListener('pointerup', release);
    el.addEventListener('pointercancel', release);
    el.addEventListener('lostpointercapture', release);
    el.addEventListener('contextmenu', (e) => e.preventDefault());
  }

  function noteTouch(e) {
    if (e.pointerType === 'touch' && !sawTouch) { sawTouch = true; refreshTouchVisibility(); }
    RR.audio.init();
  }

  function setupStick() {
    const zone = document.getElementById('stick-zone'), base = document.getElementById('stick-base'), knob = document.getElementById('stick-knob');
    const radius = () => base.offsetWidth * 0.5 || 50;
    zone.addEventListener('pointerdown', (e) => {
      if (stick.id !== null) return;
      e.preventDefault();
      noteTouch(e);
      stick.id = e.pointerId;
      const r = zone.getBoundingClientRect();
      stick.ox = e.clientX; stick.oy = e.clientY; stick.x = 0; stick.y = 0;
      base.hidden = false;
      zone.classList.add('active');
      base.style.left = e.clientX - r.left + 'px';
      base.style.top = e.clientY - r.top + 'px';
      knob.style.transform = 'translate(-50%,-50%)';
      try { zone.setPointerCapture(e.pointerId); } catch (err) { /* ignore */ }
    });
    zone.addEventListener('pointermove', (e) => {
      if (e.pointerId !== stick.id) return;
      const R = radius();
      let dx = (e.clientX - stick.ox) / R, dy = (e.clientY - stick.oy) / R;
      const l = Math.hypot(dx, dy);
      if (l > 1) { dx /= l; dy /= l; }
      stick.x = dx; stick.y = dy;
      knob.style.transform = 'translate(calc(-50% + ' + dx * R + 'px), calc(-50% + ' + dy * R + 'px))';
    });
    const end = (e) => {
      if (e.pointerId !== stick.id) return;
      stick.id = null; stick.x = 0; stick.y = 0;
      base.hidden = true;
      zone.classList.remove('active');
    };
    zone.addEventListener('pointerup', end);
    zone.addEventListener('pointercancel', end);
    zone.addEventListener('lostpointercapture', end);
    zone.addEventListener('contextmenu', (e) => e.preventDefault());
  }

  RR.input = {
    touchMode: false,
    init() {
      try { coarse = window.matchMedia('(pointer: coarse)').matches; } catch (e) { coarse = false; }
      window.addEventListener('keydown', onKeyDown);
      window.addEventListener('keyup', onKeyUp);
      window.addEventListener('blur', () => RR.input.reset());
      setupStick();
      bindButton('btn-attack', () => { st.attackPressed = true; });
      bindButton('btn-block', () => { touchBlock = true; }, () => { touchBlock = false; });
      bindButton('btn-dodge', () => { st.dodgePressed = true; });
      bindButton('btn-swap', () => { st.swapPressed = true; });
      RR.onSetting((k) => { if (k === 'touch' || k === '*') refreshTouchVisibility(); });
      refreshTouchVisibility();
    },
    // called once per simulated frame
    state() {
      let mx = 0, my = 0;
      for (const k of keys) { const m = MOVE[k]; if (m) { mx += m[0]; my += m[1]; } }
      const l = Math.hypot(stick.x, stick.y);
      if (l > 0.14) { mx += stick.x; my += stick.y; }
      st.mx = Math.max(-1, Math.min(1, mx));
      st.my = Math.max(-1, Math.min(1, my));
      st.block = touchBlock || keys.has('KeyK') || keys.has('ShiftLeft') || keys.has('ShiftRight');
      return st;
    },
    endFrame() { st.attackPressed = st.dodgePressed = st.swapPressed = false; },
    takePause() { const p = pausePressed; pausePressed = false; return p; },
    reset() {
      keys.clear();
      touchBlock = false;
      st.attackPressed = st.dodgePressed = st.swapPressed = false;
      stick.id = null; stick.x = stick.y = 0;
      const base = document.getElementById('stick-base');
      if (base) { base.hidden = true; base.parentElement.classList.remove('active'); }
    },
    get usingKeys() { return !RR.input.touchMode; },
  };
})();
