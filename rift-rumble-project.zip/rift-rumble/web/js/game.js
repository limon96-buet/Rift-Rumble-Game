/* Rift Rumble — match simulation: fighters, combat, opponents, pickups, conditions.
 * No drawing and no DOM here. The renderer reads RR.game.M; the UI drains RR.game.events.
 */
(function () {
  const RR = (window.RR = window.RR || {});
  const TAU = Math.PI * 2;
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  const hyp = Math.hypot;
  const angDiff = (a, b) => {
    let d = (a - b) % TAU;
    if (d > Math.PI) d -= TAU;
    if (d < -Math.PI) d += TAU;
    return d;
  };
  const turnToward = (a, b, step) => {
    const d = angDiff(b, a);
    return Math.abs(d) <= step ? b : a + Math.sign(d) * step;
  };

  /* seeded RNG so a match can be replayed in tests */
  let seed = 1;
  function rng() {
    seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  }
  const rand = (a, b) => a + rng() * (b - a);
  const pick = (arr) => arr[(rng() * arr.length) | 0];
  function shuffle(a) {
    for (let i = a.length - 1; i > 0; i--) {
      const j = (rng() * (i + 1)) | 0;
      const t = a[i]; a[i] = a[j]; a[j] = t;
    }
    return a;
  }

  let M = null;
  const events = [];
  const emit = (type, data) => events.push(Object.assign({ type }, data || {}));
  const sfx = (n) => RR.audio.sfx(n);

  /* ---- geometry ------------------------------------------------------- */
  function segCircle(x1, y1, x2, y2, cx, cy, r) {
    const dx = x2 - x1, dy = y2 - y1, fx = x1 - cx, fy = y1 - cy;
    const c = fx * fx + fy * fy - r * r;
    if (c <= 0) return 0;
    const a = dx * dx + dy * dy;
    if (a < 1e-9) return -1;
    const b = 2 * (fx * dx + fy * dy);
    const disc = b * b - 4 * a * c;
    if (disc < 0) return -1;
    const t = (-b - Math.sqrt(disc)) / (2 * a);
    return t >= 0 && t <= 1 ? t : -1;
  }
  function segRect(x1, y1, x2, y2, o) {
    let t0 = 0, t1 = 1;
    const dx = x2 - x1, dy = y2 - y1;
    const p = [-dx, dx, -dy, dy], q = [x1 - o.x, o.x + o.w - x1, y1 - o.y, o.y + o.h - y1];
    for (let i = 0; i < 4; i++) {
      if (p[i] === 0) { if (q[i] < 0) return -1; }
      else {
        const r = q[i] / p[i];
        if (p[i] < 0) { if (r > t1) return -1; if (r > t0) t0 = r; }
        else { if (r < t0) return -1; if (r < t1) t1 = r; }
      }
    }
    return t0;
  }
  const segObstacle = (x1, y1, x2, y2, o) => (o.r ? segCircle(x1, y1, x2, y2, o.x, o.y, o.r) : segRect(x1, y1, x2, y2, o));
  function los(x1, y1, x2, y2) {
    const obs = M.arena.obstacles;
    for (let i = 0; i < obs.length; i++) if (segObstacle(x1, y1, x2, y2, obs[i]) >= 0) return false;
    return true;
  }
  // distance from point to obstacle surface, plus outward normal
  function obstacleNear(o, x, y, out) {
    if (o.r) {
      const dx = x - o.x, dy = y - o.y, d = hyp(dx, dy) || 0.001;
      out.d = d - o.r; out.nx = dx / d; out.ny = dy / d;
    } else {
      const cx = clamp(x, o.x, o.x + o.w), cy = clamp(y, o.y, o.y + o.h);
      const dx = x - cx, dy = y - cy, d = hyp(dx, dy);
      if (d > 0.001) { out.d = d; out.nx = dx / d; out.ny = dy / d; }
      else { out.d = 0; out.nx = x < o.x + o.w / 2 ? -1 : 1; out.ny = 0; }
    }
    return out;
  }
  function collideWorld(f) {
    const A = M.arena, m = A.wall + f.r;
    f.x = clamp(f.x, m, A.w - m);
    f.y = clamp(f.y, m, A.h - m);
    const obs = A.obstacles;
    for (let i = 0; i < obs.length; i++) {
      const o = obs[i];
      if (o.r) {
        let dx = f.x - o.x, dy = f.y - o.y, d = hyp(dx, dy);
        const min = f.r + o.r;
        if (d < min) {
          if (d < 0.001) { dx = 1; dy = 0; d = 1; }
          f.x = o.x + (dx / d) * min;
          f.y = o.y + (dy / d) * min;
        }
      } else {
        const cx = clamp(f.x, o.x, o.x + o.w), cy = clamp(f.y, o.y, o.y + o.h);
        const dx = f.x - cx, dy = f.y - cy, d2 = dx * dx + dy * dy;
        if (d2 < f.r * f.r) {
          if (d2 > 1e-6) {
            const d = Math.sqrt(d2);
            f.x = cx + (dx / d) * f.r;
            f.y = cy + (dy / d) * f.r;
          } else {
            const l = f.x - o.x, r = o.x + o.w - f.x, t = f.y - o.y, b = o.y + o.h - f.y, mn = Math.min(l, r, t, b);
            if (mn === l) f.x = o.x - f.r; else if (mn === r) f.x = o.x + o.w + f.r;
            else if (mn === t) f.y = o.y - f.r; else f.y = o.y + o.h + f.r;
          }
        }
      }
    }
  }

  /* ---- effects (data only; drawn by the renderer) ---------------------- */
  function particles(x, y, n, speed, color, life, size) {
    const cap = RR.fxCap || 140;
    for (let i = 0; i < n && M.particles.length < cap; i++) {
      const a = Math.random() * TAU, s = speed * (0.35 + Math.random() * 0.65);
      M.particles.push({ x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s, life: life * (0.6 + Math.random() * 0.4), max: life, size: size || 3, color });
    }
  }
  function floatText(x, y, txt, kind) {
    M.texts.push({ x: x + (Math.random() - 0.5) * 14, y, txt, kind, life: 0.8, max: 0.8 });
    if (M.texts.length > 24) M.texts.shift();
  }

  /* ---- fighters -------------------------------------------------------- */
  function makeFighter(id, team, x, y) {
    const def = RR.FIGHTERS[id];
    const hp = team === 'enemy' ? Math.round(def.hp * M.diff.enemyHp) : def.hp;
    return {
      id, def, team, x, y, vx: 0, vy: 0, kx: 0, ky: 0, r: def.r, face: 0,
      hp, maxHp: hp, st: def.st || 0, maxSt: def.st || 0,
      state: 'idle', stT: 0, atk: null, combo: 0, comboT: 0,
      weapon: null, useFists: false, blocking: false, blockStart: -9, guardLock: false,
      iframes: 0, flash: 0, spawnT: team === 'enemy' ? 0.9 : 0, deadT: 0,
      cool: rand(0.5, 1.1), side: rng() < 0.5 ? -1 : 1, sideT: 0, blockT: 0, hopT: 0,
      dodgeA: 0, dodgeReady: 0, lastSt: -9, buf: 0, walk: 0, age: 0, armorT: 0, streak: 0, lastHitT: -9,
    };
  }
  const alive = (f) => f.state !== 'dead';
  function wepOf(f) {
    if (f.team === 'enemy') return RR.WEAPONS[f.def.weapon];
    if (f.weapon && !f.useFists) return RR.WEAPONS[f.weapon.id];
    return RR.WEAPONS.fists;
  }
  function spendSt(f, n) {
    f.st = Math.max(0, f.st - n);
    f.lastSt = M.t;
  }
  function stagger(f, t) {
    f.atk = null;
    f.state = 'stagger';
    f.stT = t;
    f.blocking = false;
    f.blockT = 0;
    f.hopT = 0;
    f.vx = f.vy = 0;
  }
  const enemies = () => M.fighters.filter((f) => f.team === 'enemy');
  function attackers() {
    let n = 0;
    for (const f of M.fighters) if (f.team === 'enemy' && f.atk && f.atk.phase !== 'r') n++;
    return n;
  }
  function nearestEnemy(p, maxD, needLos) {
    let best = null, bd = maxD;
    for (const f of M.fighters) {
      if (f.team === p.team || !alive(f) || f.spawnT > 0) continue;
      const d = hyp(f.x - p.x, f.y - p.y);
      if (d < bd && (!needLos || los(p.x, p.y, f.x, f.y))) { bd = d; best = f; }
    }
    return best;
  }

  /* ---- attacks --------------------------------------------------------- */
  function startAttack(f, aim) {
    const W = wepOf(f), isP = f.team === 'player';
    if (isP) {
      if (f.st < W.st * 0.5) return false;
      spendSt(f, W.st);
      M.stats.attacks++;
    }
    if (f.comboT <= 0) f.combo = 0;
    const idx = f.combo % W.moves.length, mv = W.moves[idx];
    const wm = isP ? 1 : M.diff.windup;
    f.atk = { W, mv, idx, phase: 'w', t: 0, wd: mv.w * wm, ad: mv.a, rd: mv.r, hit: [], landed: false };
    f.combo++;
    f.comboT = 0.7 + mv.w + mv.a + mv.r;
    f.face = aim;
    f.state = 'attack';
    f.blocking = false;
    if (isP) {
      // an opponent who can guard may react to the start of a swing
      for (const e of M.fighters) {
        const A = e.def.ai;
        if (e.team !== 'enemy' || !A || !A.block || e.state !== 'idle' || e.blockT > 0 || e.spawnT > 0) continue;
        if (W.kind === 'melee' && hyp(e.x - f.x, e.y - f.y) < W.range + 70 && rng() < A.block) e.blockT = 0.55;
      }
    } else if (W.kind === 'ranged') sfx('warn');
    return true;
  }

  function fire(f, W) {
    const c = Math.cos(f.face), s = Math.sin(f.face), ox = f.x + c * (f.r + 8), oy = f.y + s * (f.r + 8);
    M.projectiles.push({
      x: ox, y: oy, px: f.x, py: f.y, vx: c * W.proj.speed, vy: s * W.proj.speed, a: f.face,
      team: f.team, owner: f, dmg: W.proj.dmg, knock: W.proj.knock, kind: W.proj.kind, life: 1.5, skip: null,
    });
    sfx(W.proj.kind === 'arrow' ? 'bow' : 'rifle');
    if (W.proj.kind === 'bolt') {
      particles(ox, oy, 5, 160, 'spark', 0.18, 3);
      if (f.team === 'player') M.shake = Math.max(M.shake, 5);
    }
  }

  function updateAttack(f, dt, track) {
    const a = f.atk, W = a.W;
    a.t += dt;
    let lunge = 0;
    if (a.phase === 'w') {
      if (track !== null && a.wd - a.t > (W.kind === 'ranged' ? 0.24 : 0.17)) f.face = turnToward(f.face, track, (W.kind === 'ranged' ? 5 : 4) * dt);
      if (W.kind === 'melee' && a.t > a.wd * 0.45) lunge = W.lunge / (a.wd * 0.55 + a.ad);
      if (a.t >= a.wd) {
        a.phase = 'a';
        a.t = 0;
        if (W.kind === 'ranged') fire(f, W); else sfx('swing');
        if (f.team === 'player' && f.weapon && !f.useFists) f.weapon.uses--;
      }
    } else if (a.phase === 'a') {
      if (W.kind === 'melee') {
        lunge = W.lunge / (a.wd * 0.55 + a.ad);
        for (const t of M.fighters) {
          if (t.team === f.team || !alive(t) || a.hit.indexOf(t) >= 0) continue;
          const dx = t.x - f.x, dy = t.y - f.y, d = hyp(dx, dy);
          if (d > W.range + t.r * 0.5) continue;
          const ang = Math.atan2(dy, dx);
          if (Math.abs(angDiff(ang, f.face)) > W.arc / 2) continue;
          a.hit.push(t);
          const res = applyHit(f, t, a.mv.dmg, a.mv.knock, ang, 'melee', !!a.mv.heavy, W);
          if (!f.atk) return; // attacker was parried
          if (res !== 'none' && res !== 'dodged' && f.team === 'player' && !a.landed) { a.landed = true; M.stats.hits++; }
        }
      }
      if (a.t >= a.ad) { a.phase = 'r'; a.t = 0; }
    } else if (a.t >= a.rd) {
      f.atk = null;
      f.state = 'idle';
      if (f.team === 'enemy') {
        const A = f.def.ai;
        f.cool = rand(A.cd[0], A.cd[1]) * M.diff.cd;
        if (A.hop && rng() < A.hop) f.hopT = 0.22;
      } else if (f.weapon && f.weapon.uses <= 0) {
        floatText(f.x, f.y - 46, RR.t(RR.WEAPONS[f.weapon.id].kind === 'ranged' ? 'fx.empty' : 'fx.broken'), 'info');
        f.weapon = null;
        f.useFists = false;
        sfx('broken');
      }
      return;
    }
    // forward step during a swing, unless already toe-to-toe
    if (lunge > 0) {
      const tgt = nearestEnemy(f, W.range * 0.6 + f.r, false);
      if (tgt) lunge = 0;
    }
    f.vx = Math.cos(f.face) * lunge;
    f.vy = Math.sin(f.face) * lunge;
  }

  function applyHit(att, tgt, dmg, knock, ang, kind, heavy, W) {
    if (!alive(tgt) || tgt.spawnT > 0) return 'none';
    const isP = tgt.team === 'player';
    if (tgt.iframes > 0) {
      if (!tgt.dodgeShown) { floatText(tgt.x, tgt.y - 44, RR.t('fx.dodge'), 'info'); tgt.dodgeShown = true; }
      return 'dodged';
    }
    if (att.team === 'enemy') dmg *= M.diff.enemyDmg;
    let res = 'hit';
    if (tgt.blocking) {
      const src = kind === 'melee' ? Math.atan2(att.y - tgt.y, att.x - tgt.x) : ang + Math.PI;
      if (Math.abs(angDiff(src, tgt.face)) < 1.3) res = isP && M.t - tgt.blockStart <= 0.2 ? 'parry' : 'block';
    }
    const hx = tgt.x - Math.cos(ang) * tgt.r * 0.7, hy = tgt.y - Math.sin(ang) * tgt.r * 0.7;
    if (res === 'parry') {
      M.stats.parries++;
      sfx('parry');
      floatText(tgt.x, tgt.y - 48, RR.t('fx.parry'), 'good');
      particles(hx, hy, 12, 260, 'spark', 0.35, 3);
      tgt.st = Math.min(tgt.maxSt, tgt.st + 14);
      M.hitstop = 0.1;
      if (kind === 'melee' && alive(att)) {
        stagger(att, 0.9);
        att.kx -= Math.cos(ang) * 220;
        att.ky -= Math.sin(ang) * 220;
      }
      if (rng() < 0.4) bark('kade', pick(RR.BARKS.parry));
      return 'parry';
    }
    if (res === 'block') {
      dmg *= kind === 'melee' ? 0.15 : 0.3;
      knock *= 0.35;
      sfx('block');
      particles(hx, hy, 6, 180, 'spark', 0.25, 3);
      if (isP) {
        M.stats.blocks++;
        spendSt(tgt, kind === 'melee' ? (heavy ? 20 : 13) : 9);
        floatText(tgt.x, tgt.y - 44, RR.t('fx.block'), 'info');
        if (tgt.st <= 0) {
          tgt.guardLock = true;
          stagger(tgt, 0.7);
          sfx('guardbreak');
          floatText(tgt.x, tgt.y - 60, RR.t('fx.break'), 'bad');
        }
      } else if (heavy) {
        stagger(tgt, 0.55);
        sfx('guardbreak');
        floatText(tgt.x, tgt.y - 60, RR.t('fx.break'), 'good');
      }
    } else {
      if (kind === 'ranged') sfx('arrowhit');
      else if (W && W.icon === 'sword') sfx('slash');
      else sfx(heavy ? 'heavy' : 'punch');
      particles(hx, hy, heavy ? 10 : 6, heavy ? 280 : 200, isP ? 'hurt' : 'hit', 0.3, heavy ? 4 : 3);
      if (isP) { stagger(tgt, 0.16); sfx('hurt'); }
      else {
        // Opponents can be interrupted, but not stun-locked: after a finisher or three
        // quick hits they brace (no flinch for a moment) and answer back sooner.
        if (tgt.armorT <= 0 && (!tgt.def.poise || heavy || kind === 'ranged')) stagger(tgt, heavy ? 0.38 : 0.16);
        tgt.streak = M.t - tgt.lastHitT < 1.0 ? tgt.streak + 1 : 1;
        tgt.lastHitT = M.t;
        if (heavy || tgt.streak >= 3) { tgt.armorT = 1.25; tgt.streak = 0; tgt.cool = Math.min(tgt.cool, 0.2); }
      }
    }
    dmg = Math.max(1, Math.round(dmg));
    tgt.hp -= dmg;
    tgt.flash = 0.12;
    tgt.kx += Math.cos(ang) * knock;
    tgt.ky += Math.sin(ang) * knock;
    floatText(tgt.x, tgt.y - 34, String(dmg), isP ? 'bad' : res === 'block' ? 'info' : 'dmg');
    if (isP) {
      M.stats.taken += dmg;
      M.shake = Math.max(M.shake, res === 'block' ? 4 : 10);
      if (res !== 'block') RR.vibrate(35);
    } else {
      M.stats.dealt += dmg;
      M.shake = Math.max(M.shake, heavy ? 8 : 4);
    }
    M.hitstop = Math.max(M.hitstop, heavy ? 0.085 : 0.045);
    if (tgt.hp <= 0) kill(tgt, ang);
    else if (isP && tgt.hp < tgt.maxHp * 0.3 && !M.lowBarked) { M.lowBarked = true; bark('kade', pick(RR.BARKS.low)); }
    return res;
  }

  function kill(f, ang) {
    f.hp = 0;
    f.state = 'dead';
    f.deadT = 1.3;
    f.atk = null;
    f.blocking = false;
    f.kx += Math.cos(ang) * 200;
    f.ky += Math.sin(ang) * 200;
    sfx('ko');
    particles(f.x, f.y, 18, 300, f.team === 'player' ? 'hurt' : 'hit', 0.5, 4);
    M.shake = Math.max(M.shake, 14);
    M.hitstop = 0.14;
    if (f.team === 'enemy') {
      M.defeated++;
      M.lastDeathT = M.t;
      if (M.defeated >= M.lineup.length) finish('win');
      else if (rng() < M.diff.orb) M.pickups.push({ kind: 'health', amount: 15, x: f.x, y: f.y, t: 0 });
    } else finish('lose');
  }

  function bark(speaker, lineKey) {
    emit('bark', { speaker, lineKey });
  }

  function finish(result) {
    if (M.result) return;
    M.result = result;
    M.phase = 'ending';
    M.endT = 1.5;
    M.timeScale = 0.3;
    emit('ending', { result });
    if (result === 'win') bark('kade', pick(RR.BARKS.win)); else bark('ann', pick(RR.BARKS.lose));
  }

  /* ---- player ---------------------------------------------------------- */
  const NOINPUT = { mx: 0, my: 0, attackPressed: false, block: false, dodgePressed: false, swapPressed: false };

  function threatFor(p) {
    let best = null, bd = 720;
    for (const f of M.fighters) {
      if (f.team === p.team || !alive(f) || !f.atk || f.atk.phase === 'r') continue;
      const d = hyp(f.x - p.x, f.y - p.y);
      if (d < bd) { bd = d; best = f; }
    }
    return best || nearestEnemy(p, 280, false);
  }
  function autoAim(p) {
    const W = wepOf(p);
    let t;
    if (W.kind === 'melee') t = nearestEnemy(p, W.range + 130, false);
    else {
      const vis = M.condDef.vision ? M.condDef.vision + 90 : 980;
      t = nearestEnemy(p, vis, true) || nearestEnemy(p, vis, false);
    }
    return t ? Math.atan2(t.y - p.y, t.x - p.x) : p.face;
  }
  function tryDodge(p, mx, my, len) {
    if (M.t < p.dodgeReady || p.st < 20) return false;
    spendSt(p, 24);
    p.dodgeA = len > 0.2 ? Math.atan2(my, mx) : p.face + Math.PI;
    p.state = 'dodge';
    p.stT = 0.26;
    p.iframes = 0.25;
    p.dodgeShown = false;
    p.dodgeReady = M.t + 0.55;
    p.atk = null;
    p.blocking = false;
    M.stats.dodges++;
    sfx('dodge');
    particles(p.x, p.y, 6, 90, 'dust', 0.4, 5);
    return true;
  }
  function nearWeaponPickup(p, d) {
    let best = null, bd = d;
    for (const k of M.pickups) {
      if (k.kind !== 'weapon') continue;
      const dd = hyp(k.x - p.x, k.y - p.y);
      if (dd < bd) { bd = dd; best = k; }
    }
    return best;
  }
  function takeWeapon(p, k) {
    if (p.weapon) M.pickups.push({ kind: 'weapon', id: p.weapon.id, uses: p.weapon.uses, x: p.x, y: p.y + 6, t: 0, cool: 0.6 });
    p.weapon = { id: k.id, uses: k.uses };
    p.useFists = false;
    M.pickups.splice(M.pickups.indexOf(k), 1);
    M.stats.pickups++;
    sfx('pickup');
    floatText(p.x, p.y - 48, RR.t('weapon.' + k.id), 'good');
  }

  function updatePlayer(dt, inp) {
    const p = M.player;
    p.flash = Math.max(0, p.flash - dt);
    if (!alive(p)) { p.deadT -= dt; moveBody(p, dt, 0, 0, 12); return; }
    p.comboT -= dt;
    p.iframes = Math.max(0, p.iframes - dt);
    if (M.t - p.lastSt > 0.65) p.st = Math.min(p.maxSt, p.st + (p.blocking ? 9 : 27) * dt);
    if (inp.attackPressed) p.buf = 0.22; else p.buf = Math.max(0, p.buf - dt);
    let mx = inp.mx, my = inp.my, len = hyp(mx, my);
    if (len > 1) { mx /= len; my /= len; len = 1; }
    let tvx = 0, tvy = 0, acc = M.condDef.slick ? 5.5 : 16;

    if (p.state === 'stagger') {
      p.stT -= dt;
      if (p.stT <= 0) p.state = 'idle';
    } else if (p.state === 'dodge') {
      p.stT -= dt;
      const sp = 640 * (M.condDef.slick ? 1.12 : 1);
      tvx = Math.cos(p.dodgeA) * sp;
      tvy = Math.sin(p.dodgeA) * sp;
      acc = 40;
      if (p.stT <= 0) p.state = 'idle';
    } else if (p.state === 'attack') {
      updateAttack(p, dt, null);
      tvx = p.vx; tvy = p.vy; acc = 40;
      if (p.atk && p.atk.phase === 'r') {
        if (inp.dodgePressed) tryDodge(p, mx, my, len);
        else if (p.buf > 0 && p.atk.t > p.atk.rd * 0.55 && p.atk.idx < p.atk.W.moves.length - 1 && p.st >= p.atk.W.st * 0.5) {
          // combo: chain the next move without waiting out the full recovery
          p.atk = null; p.state = 'idle';
          if (startAttack(p, autoAim(p))) p.buf = 0;
        }
      }
    } else {
      const wantBlock = inp.block && p.st > 1 && !p.guardLock;
      if (!inp.block) p.guardLock = false;
      if (wantBlock && !p.blocking) p.blockStart = M.t;
      p.blocking = wantBlock;
      const sp = p.def.speed * (p.blocking ? 0.45 : 1);
      tvx = mx * sp; tvy = my * sp;
      if (p.blocking) {
        const th = threatFor(p);
        if (th) p.face = turnToward(p.face, Math.atan2(th.y - p.y, th.x - p.x), 16 * dt);
        else if (len > 0.15) p.face = turnToward(p.face, Math.atan2(my, mx), 12 * dt);
      } else if (len > 0.15) p.face = turnToward(p.face, Math.atan2(my, mx), 14 * dt);
      if (inp.dodgePressed) tryDodge(p, mx, my, len);
      else if (p.buf > 0 && !p.blocking) { if (startAttack(p, autoAim(p))) p.buf = 0; }
      if (inp.swapPressed && p.state === 'idle') {
        const k = nearWeaponPickup(p, 50);
        if (k) takeWeapon(p, k);
        else if (p.weapon) { p.useFists = !p.useFists; sfx('ui'); }
      }
    }
    const ox = p.x, oy = p.y;
    moveBody(p, dt, tvx, tvy, acc);
    const moved = hyp(p.x - ox, p.y - oy);
    M.stats.moved += moved;
    p.walk += moved * 0.045;

    // pickups
    M.nearTake = false;
    for (let i = M.pickups.length - 1; i >= 0; i--) {
      const k = M.pickups[i];
      const d = hyp(k.x - p.x, k.y - p.y);
      if (k.kind === 'weapon') {
        if (k.cool > 0) { k.cool -= dt; continue; }
        if (!p.weapon && d < 36 && p.state !== 'dodge') takeWeapon(p, k);
        else if (p.weapon && d < 50) M.nearTake = true;
      } else if (d < 38 && p.hp < p.maxHp) {
        const before = p.hp;
        p.hp = Math.min(p.maxHp, p.hp + k.amount);
        floatText(p.x, p.y - 46, '+' + Math.round(p.hp - before), 'good');
        sfx('heal');
        particles(p.x, p.y, 10, 120, 'heal', 0.5, 3);
        M.pickups.splice(i, 1);
      }
    }
  }

  function moveBody(f, dt, tvx, tvy, acc) {
    const k = Math.min(1, acc * dt);
    f.vx += (tvx - f.vx) * k;
    f.vy += (tvy - f.vy) * k;
    f.x += (f.vx + f.kx) * dt;
    f.y += (f.vy + f.ky) * dt;
    const decay = Math.exp(-9 * dt);
    f.kx *= decay; f.ky *= decay;
    collideWorld(f);
  }

  /* ---- opponents ------------------------------------------------------- */
  const _o = { d: 0, nx: 0, ny: 0 };
  function steer(e, mx, my) {
    const A = M.arena;
    for (const o of A.obstacles) {
      obstacleNear(o, e.x, e.y, _o);
      const range = e.r + 48;
      if (_o.d < range && mx * _o.nx + my * _o.ny < 0.25) {
        const w = 1 - Math.max(0, _o.d) / range;
        let tx = -_o.ny, ty = _o.nx;
        if (tx * mx + ty * my < 0) { tx = -tx; ty = -ty; }
        if (Math.abs(tx * mx + ty * my) < 0.15) { tx *= e.side; ty *= e.side; }
        mx += _o.nx * w * 1.1 + tx * w * 1.5;
        my += _o.ny * w * 1.1 + ty * w * 1.5;
      }
    }
    const m = A.wall + e.r, band = 70;
    if (e.x < m + band) mx += 1 - (e.x - m) / band;
    if (e.x > A.w - m - band) mx -= 1 - (A.w - m - e.x) / band;
    if (e.y < m + band) my += 1 - (e.y - m) / band;
    if (e.y > A.h - m - band) my -= 1 - (A.h - m - e.y) / band;
    for (const f of M.fighters) {
      if (f === e || f.team !== 'enemy' || !alive(f)) continue;
      const dx = e.x - f.x, dy = e.y - f.y, d = hyp(dx, dy);
      if (d < 80 && d > 0.01) { mx += (dx / d) * (1 - d / 80); my += (dy / d) * (1 - d / 80); }
    }
    _o.nx = mx; _o.ny = my;
    return _o;
  }

  function updateEnemy(e, dt) {
    e.flash = Math.max(0, e.flash - dt);
    e.age += dt;
    if (!alive(e)) { e.deadT -= dt; moveBody(e, dt, 0, 0, 10); return; }
    const p = M.player, D = M.diff, A = e.def.ai;
    const pa = Math.atan2(p.y - e.y, p.x - e.x), pd = hyp(p.x - e.x, p.y - e.y);
    if (e.spawnT > 0) { e.spawnT -= dt; e.face = pa; return; }
    e.comboT -= dt;
    e.armorT = Math.max(0, e.armorT - dt);
    let tvx = 0, tvy = 0, acc = M.condDef.slick ? 6 : 12;
    if (e.state === 'stagger') {
      e.stT -= dt;
      if (e.stT <= 0) e.state = 'idle';
    } else if (e.state === 'attack') {
      updateAttack(e, dt, alive(p) ? pa : null);
      tvx = e.vx; tvy = e.vy; acc = 40;
    } else if (e.blockT > 0) {
      e.blockT -= dt;
      e.blocking = e.blockT > 0;
      e.face = turnToward(e.face, pa, 10 * dt);
    } else if (e.hopT > 0) {
      e.hopT -= dt;
      tvx = -Math.cos(pa) * 430; tvy = -Math.sin(pa) * 430; acc = 30;
    } else {
      e.blocking = false;
      e.cool -= dt;
      e.sideT -= dt;
      if (e.sideT <= 0) { e.side = rng() < 0.5 ? -1 : 1; e.sideT = rand(1.2, 2.6); }
      const W = wepOf(e), dx = Math.cos(pa), dy = Math.sin(pa), tx = -dy * e.side, ty = dx * e.side;
      let mx = 0, my = 0, speed = e.def.speed;
      if (alive(p)) {
        const see = los(e.x, e.y, p.x, p.y);
        const canAtk = e.cool <= 0 && attackers() < D.attackers;
        if (A.type === 'melee') {
          const reach = W.range + p.r * 0.4;
          if (pd > reach * 0.92) {
            if (!canAtk && pd < 190) { mx = tx * 0.9 + dx * 0.15; my = ty * 0.9 + dy * 0.15; speed *= 0.7; }
            else { const s = pd < 280 ? 0.3 : 0; mx = dx + tx * s; my = dy + ty * s; }
          } else if (!canAtk) { mx = tx * 0.7 - dx * 0.55; my = ty * 0.7 - dy * 0.55; speed *= 0.6; }
          if (canAtk && see && pd <= reach + W.lunge * 0.55) startAttack(e, pa);
        } else {
          const visR = M.condDef.vision ? M.condDef.vision + 40 : 1e9;
          const maxR = Math.min(A.max, visR * 0.9), minR = Math.min(A.min, maxR * 0.6), fireMax = Math.min(A.fireMax, visR);
          if (pd < minR) { mx = -dx + tx * 0.6; my = -dy + ty * 0.6; }
          else if (pd > maxR || !see) { const s = see ? 0.3 : 0.9; mx = dx + tx * s; my = dy + ty * s; }
          else { mx = tx; my = ty; speed *= 0.55; }
          if (canAtk && see && pd < fireMax && pd > 80) startAttack(e, pa);
        }
      }
      if (e.state === 'idle') {
        const s = steer(e, mx, my);
        const l = hyp(s.nx, s.ny);
        if (l > 0.05) { tvx = (s.nx / l) * speed; tvy = (s.ny / l) * speed; }
        e.face = turnToward(e.face, pa, 7 * dt);
      }
    }
    const ox = e.x, oy = e.y;
    moveBody(e, dt, tvx, tvy, acc);
    e.walk += hyp(e.x - ox, e.y - oy) * 0.045;
  }

  function separate() {
    const fs = M.fighters;
    for (let i = 0; i < fs.length; i++) {
      for (let j = i + 1; j < fs.length; j++) {
        const a = fs[i], b = fs[j];
        if (!alive(a) || !alive(b) || a.state === 'dodge' || b.state === 'dodge') continue;
        const dx = b.x - a.x, dy = b.y - a.y, d = hyp(dx, dy), min = a.r + b.r;
        if (d < min && d > 0.001) {
          const push = (min - d) / 2;
          a.x -= (dx / d) * push; a.y -= (dy / d) * push;
          b.x += (dx / d) * push; b.y += (dy / d) * push;
        }
      }
    }
  }

  function spawnEnemy() {
    const A = M.arena, p = M.player, id = M.lineup[M.spawned];
    const far = A.spawns.filter((s) => hyp(s.x - p.x, s.y - p.y) > 380);
    const s = pick(far.length ? far : A.spawns);
    const e = makeFighter(id, 'enemy', s.x, s.y);
    e.face = Math.atan2(p.y - e.y, p.x - e.x);
    M.fighters.push(e);
    M.spawned++;
    M.lastSpawnT = M.t;
    sfx('spawn');
    particles(s.x, s.y, 14, 160, 'rift', 0.6, 4);
    const last = M.spawned === M.lineup.length && M.lineup.length > 1;
    emit('banner', { key: last ? 'ann.final' : 'ann.enters', vars: { name: RR.t('fighter.' + id + '.name') }, sub: last ? RR.t('fighter.' + id + '.name') : RR.t('fighter.' + id + '.role') });
    bark(id, pick(RR.BARKS[id]));
  }

  function updateSpawns() {
    if (M.spawned >= M.lineup.length) return;
    let n = 0;
    for (const f of M.fighters) if (f.team === 'enemy' && alive(f)) n++;
    let due;
    if (M.spawned === 0) due = M.t >= M.firstSpawnAt;
    else if (n === 0) due = M.t - M.lastDeathT > 0.9;
    else due = M.t - M.lastSpawnT > (M.spawned === 1 ? 13 : 15);
    if (due && n < M.maxAlive) spawnEnemy();
  }

  /* ---- projectiles, supply drop ---------------------------------------- */
  function updateProjectiles(dt) {
    const A = M.arena, ps = M.projectiles;
    for (let i = ps.length - 1; i >= 0; i--) {
      const p = ps[i];
      p.px = p.x; p.py = p.y;
      const nx = p.x + p.vx * dt, ny = p.y + p.vy * dt;
      let tHit = 2, hitF = null;
      for (const o of A.obstacles) {
        const t = segObstacle(p.x, p.y, nx, ny, o);
        if (t >= 0 && t < tHit) tHit = t;
      }
      for (const f of M.fighters) {
        if (f.team === p.team || !alive(f) || f.spawnT > 0 || f === p.skip) continue;
        const t = segCircle(p.x, p.y, nx, ny, f.x, f.y, f.r + 5);
        if (t >= 0 && t < tHit) { tHit = t; hitF = f; }
      }
      let gone = false;
      if (tHit <= 1) {
        p.x += (nx - p.x) * tHit; p.y += (ny - p.y) * tHit;
        if (hitF) {
          const res = applyHit(p.owner, hitF, p.dmg, p.knock, p.a, 'ranged', false, null);
          if (res === 'dodged') { p.skip = hitF; p.x = nx; p.y = ny; }
          else {
            gone = true;
            if (p.team === 'player' && !p.counted) { p.counted = true; M.stats.hits++; }
          }
        } else { gone = true; sfx('thunk'); particles(p.x, p.y, 5, 140, 'spark', 0.25, 3); }
      } else { p.x = nx; p.y = ny; }
      p.life -= dt;
      const w = A.wall;
      if (!gone && (p.x < w || p.x > A.w - w || p.y < w || p.y > A.h - w)) { gone = true; sfx('thunk'); particles(p.x, p.y, 5, 140, 'spark', 0.25, 3); }
      if (gone || p.life <= 0) ps.splice(i, 1);
    }
  }

  function freeSpot(minD, maxD) {
    const A = M.arena, p = M.player;
    for (let i = 0; i < 40; i++) {
      const x = rand(A.wall + 110, A.w - A.wall - 110), y = rand(A.wall + 110, A.h - A.wall - 110);
      const d = hyp(x - p.x, y - p.y);
      if (d < minD || d > maxD) continue;
      let ok = true;
      for (const o of A.obstacles) { obstacleNear(o, x, y, _o); if (_o.d < 70) { ok = false; break; } }
      if (ok) return { x, y };
    }
    return { x: A.w / 2, y: A.h * 0.72 };
  }

  function updateSupply(dt) {
    const S = M.supply;
    if (!S) return;
    if (S.state === 'wait') {
      if (M.t >= S.at) {
        const s = freeSpot(200, 480);
        S.x = s.x; S.y = s.y; S.state = 'marker'; S.timer = 3.2;
        emit('banner', { key: 'ann.supply', sub: RR.t('cond.supply.desc') });
        bark('ann', pick(RR.BARKS.supply));
      }
    } else if (S.state === 'marker') {
      S.timer -= dt;
      if (S.timer <= 0) {
        S.state = 'landed';
        sfx('crate');
        M.shake = Math.max(M.shake, 9);
        particles(S.x, S.y, 16, 200, 'dust', 0.6, 6);
        const p = M.player;
        if (hyp(p.x - S.x, p.y - S.y) < 60) { p.kx += (p.x - S.x) * 6; p.ky += (p.y - S.y) * 6; }
      }
    } else if (S.state === 'landed') {
      const p = M.player;
      if (alive(p) && hyp(p.x - S.x, p.y - S.y) < p.r + 34) {
        S.state = 'open';
        sfx('pickup');
        particles(S.x, S.y, 14, 220, 'spark', 0.4, 4);
        M.pickups.push({ kind: 'medkit', amount: 35, x: S.x - 30, y: S.y + 4, t: 0 });
        M.pickups.push({ kind: 'weapon', id: S.weapon, uses: RR.WEAPONS[S.weapon].uses, x: S.x + 30, y: S.y + 4, t: 0, cool: 0.4 });
      }
    }
  }

  /* ---- camera ---------------------------------------------------------- */
  function updateCamera(dt) {
    const v = RR.view || { w: 820, h: 460 }, A = M.arena, p = M.player, s = RR.settings.cam;
    let tx = p.x + Math.cos(p.face) * 46 * s + p.vx * 0.1 * s;
    let ty = p.y + Math.sin(p.face) * 46 * s + p.vy * 0.1 * s;
    const pad = 40;
    const hx = v.w / 2, hy = v.h / 2;
    tx = v.w >= A.w + pad * 2 ? A.w / 2 : clamp(tx, hx - pad, A.w - hx + pad);
    ty = v.h >= A.h + pad * 2 ? A.h / 2 : clamp(ty, hy - pad, A.h - hy + pad);
    const k = 1 - Math.exp(-5.5 * s * dt);
    M.cam.x += (tx - M.cam.x) * k;
    M.cam.y += (ty - M.cam.y) * k;
  }

  /* ---- match lifecycle ------------------------------------------------- */
  function newMatch(opts) {
    opts = opts || {};
    seed = opts.seed !== undefined ? opts.seed >>> 0 : (Math.random() * 4294967296) >>> 0;
    const arenaId = opts.arena || 'sundial', arena = RR.ARENAS[arenaId];
    const diffId = RR.DIFFICULTY[opts.diff] ? opts.diff : 'normal', diff = RR.DIFFICULTY[diffId];
    const cond = RR.CONDITIONS[opts.cond] ? opts.cond : pick(RR.CONDITION_IDS);
    const hasSupply = opts.supply === 'on' ? true : opts.supply === 'off' ? false : rng() < 0.55;
    const pool = shuffle(RR.PICKUP_WEAPONS.slice());
    const weaponSet = pool.slice(0, 2);
    const lineup = shuffle(RR.OPPONENTS.slice()).slice(0, diff.count);
    events.length = 0;
    M = {
      arenaId, arena, diffId, diff, cond, condDef: RR.CONDITIONS[cond], weaponSet, lineup,
      hints: !!opts.hints, phase: 'intro', introT: opts.skipIntro ? 0.05 : 2.9, t: 0, realT: 0,
      fighters: [], projectiles: [], pickups: [], particles: [], texts: [],
      spawned: 0, defeated: 0, lastSpawnT: 0, lastDeathT: 0, firstSpawnAt: opts.hints ? 6.5 : 1.0,
      maxAlive: 2,
      stats: { dealt: 0, taken: 0, blocks: 0, parries: 0, attacks: 0, hits: 0, dodges: 0, moved: 0, pickups: 0 },
      hitstop: 0, shake: 0, timeScale: 1, result: null, endT: 0, nearTake: false, lowBarked: false,
      supply: hasSupply ? { state: 'wait', at: rand(13, 20), x: 0, y: 0, timer: 0, weapon: pool[2] } : null,
      cam: { x: arena.playerSpawn.x, y: arena.playerSpawn.y }, score: 0, stars: 0,
    };
    const p = makeFighter(opts.fighter || 'kade', 'player', arena.playerSpawn.x, arena.playerSpawn.y);
    p.face = -Math.PI / 2;
    M.player = p;
    M.fighters.push(p);
    const spots = shuffle(arena.pickupSpots.slice());
    weaponSet.forEach((id, i) => M.pickups.push({ kind: 'weapon', id, uses: RR.WEAPONS[id].uses, x: spots[i].x, y: spots[i].y, t: i, cool: 0 }));
    emit('matchstart', {});
    return M;
  }

  function computeScore() {
    const s = M.stats, p = M.player, win = M.result === 'win';
    let score = M.defeated * 300 + Math.round(s.dealt) + s.parries * 60 + s.blocks * 10;
    if (win) score += 500 + Math.max(0, Math.round((150 - M.t) * 5)) + Math.round(p.hp * 6);
    M.score = Math.round(score * M.diff.score);
    M.stars = win ? 1 + (p.hp >= p.maxHp * 0.5 ? 1 : 0) + (M.t <= 90 ? 1 : 0) : 0;
  }

  function updateFx(dt) {
    const ps = M.particles;
    for (let i = ps.length - 1; i >= 0; i--) {
      const q = ps[i];
      q.life -= dt;
      if (q.life <= 0) { ps[i] = ps[ps.length - 1]; ps.pop(); continue; }
      q.x += q.vx * dt; q.y += q.vy * dt;
      q.vx *= 1 - Math.min(1, 4 * dt); q.vy *= 1 - Math.min(1, 4 * dt);
    }
    const ts = M.texts;
    for (let i = ts.length - 1; i >= 0; i--) {
      ts[i].life -= dt;
      ts[i].y -= 46 * dt;
      if (ts[i].life <= 0) ts.splice(i, 1);
    }
    for (const k of M.pickups) k.t += dt;
  }

  function update(realDt, inp) {
    if (!M) return;
    M.realT += realDt;
    if (M.phase === 'intro') {
      M.introT -= realDt;
      updateCamera(realDt);
      if (M.introT <= 0) {
        M.phase = 'fight';
        sfx('fight');
        emit('banner', { key: 'ann.fight', big: true });
        bark('kade', pick(RR.BARKS.start));
      }
      return;
    }
    if (M.phase === 'over') { updateFx(realDt); return; }
    if (M.phase === 'ending') {
      M.endT -= realDt;
      if (M.endT <= 0) { M.phase = 'over'; computeScore(); emit('over', { result: M.result }); return; }
    }
    M.shake = Math.max(0, M.shake - realDt * 40);
    let dt = realDt * M.timeScale;
    if (M.hitstop > 0) { M.hitstop -= realDt; dt = 0; }
    if (dt > 0) {
      const fighting = M.phase === 'fight';
      if (fighting) M.t += dt;
      updatePlayer(dt, fighting ? inp : NOINPUT);
      for (const f of M.fighters) if (f.team === 'enemy') updateEnemy(f, dt);
      separate();
      for (const f of M.fighters) if (alive(f)) collideWorld(f);
      updateProjectiles(dt);
      if (fighting) { updateSupply(dt); updateSpawns(); }
      for (let i = M.fighters.length - 1; i >= 0; i--) {
        const f = M.fighters[i];
        if (f.team === 'enemy' && !alive(f) && f.deadT <= 0) M.fighters.splice(i, 1);
      }
      updateFx(dt);
    }
    updateCamera(realDt);
  }

  RR.game = {
    newMatch,
    update,
    events,
    get M() { return M; },
    clear() { M = null; events.length = 0; },
    wepOf,
    enemies,
    los: (a, b, c, d) => (M ? los(a, b, c, d) : true),
  };
})();
