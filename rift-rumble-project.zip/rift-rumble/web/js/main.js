/* Rift Rumble — boot, app state, main loop. */
(function () {
  const RR = (window.RR = window.RR || {});
  const $ = (id) => document.getElementById(id);
  RR.fontDisplay = '"Big Shoulders Display", "Arial Narrow", "Roboto Condensed", Impact, sans-serif';
  RR.version = '0.1.0';

  RR.app = {
    inMatch: false,
    paused: false,
    startMatch(opts) {
      RR.audio.init();
      RR.audio.resume();
      RR.input.reset();
      const s = RR.settings;
      RR.game.newMatch(Object.assign({ arena: 'sundial', fighter: 'kade', cond: s.cond, supply: s.supply, diff: s.diff, hints: s.hints }, opts || {}));
      this.inMatch = true;
      this.paused = false;
      $('rr').classList.remove('paused');
      RR.ui.clearStack();
      RR.ui.matchStart(RR.game.M);
    },
    pause() {
      const M = RR.game.M;
      if (!this.inMatch || this.paused || !M || M.phase === 'ending' || M.phase === 'over') return;
      this.paused = true;
      $('rr').classList.add('paused');
      RR.input.reset();
      RR.ui.clearStack();
      RR.ui.show('pause');
      RR.audio.music('off');
      RR.audio.hush();
    },
    resume() {
      if (!this.paused) return;
      this.paused = false;
      $('rr').classList.remove('paused');
      RR.ui.clearStack();
      RR.ui.hideScreens();
      RR.audio.music('fight');
    },
    quit() {
      this.inMatch = false;
      this.paused = false;
      $('rr').classList.remove('paused');
      RR.game.clear();
      $('hud').hidden = true;
      $('card').hidden = true;
      RR.audio.rain(false);
      RR.audio.hush();
      RR.audio.music('menu');
      RR.ui.clearStack();
      RR.ui.show('menu');
    },
    onMatchOver() { this.inMatch = false; },
  };

  // Back / Escape: returns false only when there is nothing left to go back to.
  RR.onBack = function () {
    const a = RR.app, cur = RR.ui.current;
    if (a.inMatch && !a.paused) { a.pause(); return true; }
    if (a.paused) { RR.ui.back(); return true; }
    if (cur === 'results') { a.quit(); return true; }
    if (cur && cur !== 'menu') { RR.ui.back(); return true; }
    return false;
  };
  // Called by the Android wrapper (and by tab visibility) when the app goes to the background.
  RR.onHostPause = function () { RR.app.pause(); RR.audio.hush(); RR.audio.suspend(); };
  RR.onHostResume = function () { RR.audio.resume(); };

  let last = 0;
  function loop(ts) {
    requestAnimationFrame(loop);
    if (!last) { last = ts; return; }
    let dt = (ts - last) / 1000;
    if (RR.settings.fps30 && dt < 0.03) return;
    last = ts;
    dt = Math.min(dt, 0.05);
    if (RR.input.takePause()) RR.onBack();
    const a = RR.app;
    const live = a.inMatch && !a.paused;
    if (live) {
      RR.game.update(dt, RR.input.state());
      RR.input.endFrame();
    }
    RR.ui.frame(a.paused ? 0 : dt);
    RR.render.frame(a.paused ? 0 : dt);
  }

  function boot() {
    RR.render.init($('cv'));
    RR.input.init();
    RR.ui.init();
    document.addEventListener('visibilitychange', () => { if (document.hidden) RR.onHostPause(); else RR.onHostResume(); });
    // keep the page from scrolling or zooming under the game
    $('rr').addEventListener('touchmove', (e) => { if (!e.target.closest('.body')) e.preventDefault(); }, { passive: false });
    $('rr').addEventListener('contextmenu', (e) => e.preventDefault());
    // redraw canvas-drawn UI once the display font is ready
    if (document.fonts && document.fonts.load) {
      document.fonts.load('900 20px "Big Shoulders Display"').catch(() => {});
    }
    requestAnimationFrame(loop);
  }

  // Published-page hot reload hook (absent everywhere else).
  const hot = window.claude && window.claude.hot;
  if (hot && hot.ready) hot.ready(boot); else boot();
})();
