/* Rift Rumble — localization.
 * Every piece of on-screen text is looked up here by key. To add a language:
 *   1. Copy the `en` table, translate the values, register it as RR.LOCALES.<code>.
 *   2. Give it a `_name` (shown in Settings > Language).
 * Missing keys fall back to English, so a partial translation still works.
 * Placeholders use {name} and are filled by RR.t(key, {name: value}).
 */
(function () {
  const RR = (window.RR = window.RR || {});

  RR.LOCALES = {
    en: {
      _name: 'English',

      'app.title': 'Rift Rumble',
      'app.title.a': 'Rift',
      'app.title.b': 'Rumble',
      'app.working': 'Working title',
      'app.tagline': 'Every match rolls a new storm.',
      'menu.play': 'Quick Play',
      'menu.howto': 'How to Play',
      'menu.settings': 'Settings',
      'menu.packs': 'Content Packs',
      'menu.best': 'Best score {n}',
      'menu.build': 'First playable build · works offline · no ads · no purchases',
      'menu.rotate': 'Turn your phone sideways for a wider view.',

      'ui.back': 'Back',
      'ui.on': 'On',
      'ui.off': 'Off',

      'fighter.title': 'Choose your fighter',
      'fighter.next': 'Pick the arena',
      'fighter.opponents': 'Opponents you may face',
      'fighter.locked': 'Planned fighter',
      'fighter.locked.note': 'Not in this version',
      'fighter.kade.name': 'Tamsin Kade',
      'fighter.kade.role': 'Riftrunner',
      'fighter.kade.desc': 'Quick hands, quicker feet. Kade fights with whatever the Rift throws into the yard.',
      'fighter.brakk.name': 'Brakk Oldiron',
      'fighter.brakk.role': 'Bruiser',
      'fighter.sable.name': 'Sable Wrenn',
      'fighter.sable.role': 'Duelist',
      'fighter.quill.name': 'Quill Maro',
      'fighter.quill.role': 'Archer',
      'fighter.dax.name': 'Dax Verrin',
      'fighter.dax.role': 'Marksman',
      'stat.power': 'Power',
      'stat.speed': 'Speed',
      'stat.guard': 'Guard',

      'arena.title': 'Set the match',
      'arena.fight': 'Fight',
      'arena.conditions': 'Conditions',
      'arena.supply': 'Supply drop',
      'arena.difficulty': 'Difficulty',
      'arena.planned': 'Planned arenas · not in this version',
      'arena.sundial.name': 'Sundial Yard',
      'arena.sundial.desc': 'A cracked courtyard around a broken sundial. Pillars and crates give cover.',
      'arena.bronzegate.name': 'Bronze Gate',
      'arena.steamworks.name': 'Steamworks Pier',
      'arena.ferncanyon.name': 'Fern Canyon',
      'arena.neonflats.name': 'Neon Flats',

      'cond.random': 'Random',
      'cond.clear': 'Clear',
      'cond.fog': 'Fog',
      'cond.rain': 'Rain',
      'cond.night': 'Night',
      'cond.supply': 'Supply drop',
      'cond.clear.desc': 'No weather modifier',
      'cond.fog.desc': 'Short sight lines',
      'cond.rain.desc': 'Slick footing',
      'cond.night.desc': 'Low light',
      'cond.supply.desc': 'A crate lands mid-match',
      'supply.random': 'Random',
      'supply.on': 'On',
      'supply.off': 'Off',
      'diff.easy': 'Easy',
      'diff.normal': 'Normal',
      'diff.hard': 'Hard',

      'packs.title': 'Content packs',
      'packs.note': 'Only the Core pack is in this version. The rest are plans, listed so you can see where the game could go. Each would be an optional download.',
      'packs.installed': 'Installed',
      'packs.planned': 'Planned',
      'pack.core.name': 'Core Yard',
      'pack.core.desc': 'One fighter, four opponents, one arena, four weapons, four conditions.',
      'pack.ancient.name': 'Ancient and Medieval Fields',
      'pack.ancient.desc': 'Shield walls, spears and stone forts in invented kingdoms.',
      'pack.early1900s.name': 'Early 1900s',
      'pack.early1900s.desc': 'Rail yards, airship docks and brass-era gear in a fictional setting.',
      'pack.prehistoric.name': 'Prehistoric Survival',
      'pack.prehistoric.desc': 'A separate survival mode with stylized creatures. Hide, outrun or scare them off without hurting them.',
      'pack.future.name': 'Modern and Future Fronts',
      'pack.future.desc': 'Fictional vehicles, drones and energy weapons on invented battlefields.',
      'pack.climates.name': 'Climates and Seasons',
      'pack.climates.desc': 'Snow, desert heat, monsoon and autumn variants of each arena.',

      'howto.title': 'How to play',
      'howto.goal': 'Defeat every opponent before your health runs out.',
      'howto.touch.title': 'Touch',
      'howto.touch.move': 'Drag on the movement side of the screen to move.',
      'howto.touch.attack': 'ATTACK strikes the nearest opponent. Three punches make a combo.',
      'howto.touch.block': 'Hold BLOCK to guard. Block just as a hit lands to parry it.',
      'howto.touch.dodge': 'DODGE dashes through attacks.',
      'howto.touch.swap': 'Walk over a weapon to pick it up. SWAP switches between weapon and fists. TAKE trades for the weapon at your feet.',
      'howto.keys.title': 'Keyboard',
      'howto.keys.move': 'Move: WASD or arrow keys',
      'howto.keys.attack': 'Attack: J or Space',
      'howto.keys.block': 'Block: K or Shift',
      'howto.keys.dodge': 'Dodge: L',
      'howto.keys.swap': 'Swap or take: Q',
      'howto.keys.pause': 'Pause: Esc or P',
      'howto.tips.title': 'Reading the fight',
      'howto.tips.warn': 'A warning cone or line shows where an opponent is about to strike.',
      'howto.tips.stamina': 'Attacks, blocks and dodges use stamina. It refills when you ease off.',
      'howto.tips.weapons': 'Weapons wear out. Fists never do.',

      'settings.title': 'Settings',
      'set.game': 'Game',
      'set.controls': 'Controls',
      'set.audio': 'Audio',
      'set.graphics': 'Graphics',
      'set.access': 'Accessibility',
      'set.language': 'Language',
      'set.hints': 'First-match hints',
      'set.layout': 'Control layout',
      'layout.right': 'Right-handed',
      'layout.left': 'Left-handed',
      'set.touch': 'Touch buttons',
      'touch.auto': 'Auto',
      'touch.always': 'Always show',
      'set.uiscale': 'Interface size',
      'set.cam': 'Camera sensitivity',
      'set.vibrate': 'Vibration',
      'set.master': 'Master volume',
      'set.sfx': 'Effects volume',
      'set.music': 'Music volume',
      'set.voice': 'Voice lines',
      'set.voice.note': 'Spoken with your device voice when one is available.',
      'set.subs': 'Subtitles',
      'set.quality': 'Graphics quality',
      'q.low': 'Low',
      'q.med': 'Medium',
      'q.high': 'High',
      'set.quality.note': 'Low is the performance mode: lower resolution and fewer effects.',
      'set.fps30': 'Battery saver (30 FPS)',
      'set.showfps': 'Show frame rate',
      'set.shake': 'Screen shake',
      'set.colorblind': 'Colorblind-friendly colors',
      'set.colorblind.note': 'Uses a blue and orange palette. Shapes and labels are always shown as well.',
      'set.reset': 'Reset all settings',
      'set.reset.done': 'Settings reset',
      'set.about': 'About',
      'about.version': 'Version {v} · first playable build',
      'about.privacy': 'Privacy: this game collects no personal data and sends nothing over the network. Settings and your best score are saved only on this device.',
      'about.credits': 'Fonts: Big Shoulders Display and Barlow Semi Condensed, used under the SIL Open Font License 1.1.',

      'hud.hp': 'HP',
      'hud.st': 'STA',
      'hud.low': 'LOW',
      'hud.opponents': 'Opponents',
      'hud.pause': 'Pause',
      'hud.fps': '{n} FPS',
      'hud.keys': 'WASD move · J attack · K block · L dodge · Q swap · Esc pause',
      'btn.attack': 'ATTACK',
      'btn.block': 'BLOCK',
      'btn.dodge': 'DODGE',
      'btn.swap': 'SWAP',
      'btn.take': 'TAKE',
      'weapon.fists': 'Fists',
      'weapon.sword': 'Courtblade',
      'weapon.bow': 'Gale Bow',
      'weapon.rifle': 'Ember Rifle',

      'intro.tonight': 'Tonight in the yard',
      'intro.vs': 'VS',
      'intro.weapons': 'Weapons',
      'ann.fight': 'Fight!',
      'ann.enters': '{name} enters',
      'ann.supply': 'Supply drop',
      'ann.final': 'Final opponent',

      'fx.parry': 'PARRY',
      'fx.block': 'BLOCK',
      'fx.dodge': 'DODGE',
      'fx.break': 'GUARD BREAK',
      'fx.empty': 'EMPTY',
      'fx.broken': 'BROKEN',

      'hint.move.touch': 'Drag on the movement side of the screen to move.',
      'hint.move.keys': 'Move with WASD or the arrow keys.',
      'hint.attack.touch': 'Tap ATTACK. Three punches make a combo.',
      'hint.attack.keys': 'Press J or Space to attack. Three punches make a combo.',
      'hint.block.touch': 'Hold BLOCK when a warning appears. Block late to parry.',
      'hint.block.keys': 'Hold K when a warning appears. Block late to parry.',
      'hint.dodge.touch': 'DODGE dashes through attacks. It costs stamina.',
      'hint.dodge.keys': 'Press L to dodge through attacks. It costs stamina.',
      'hint.weapon.touch': 'Walk over a weapon to pick it up. SWAP returns to fists.',
      'hint.weapon.keys': 'Walk over a weapon to pick it up. Q returns to fists.',
      'hint.done': 'You know the basics. Good luck.',

      'pause.title': 'Paused',
      'pause.resume': 'Resume',
      'pause.restart': 'Restart match',
      'pause.settings': 'Settings',
      'pause.quit': 'Quit to menu',

      'res.victory': 'Victory',
      'res.defeat': 'Defeated',
      'res.time': 'Time',
      'res.score': 'Score',
      'res.best': 'Best {n}',
      'res.newbest': 'New best',
      'res.defeated': 'Opponents defeated',
      'res.dealt': 'Damage dealt',
      'res.taken': 'Damage taken',
      'res.blocks': 'Blocks',
      'res.parries': 'Parries',
      'res.accuracy': 'Attacks landed',
      'res.stars': '{n} of 3 stars',
      'res.rematch': 'Rematch',
      'res.setup': 'Change setup',
      'res.menu': 'Main menu',

      'speaker.ann': 'Announcer',
      'bark.kade.start1': 'New storm, same rules.',
      'bark.kade.start2': "Let's see what the Rift dragged in.",
      'bark.kade.start3': 'Yard is open. Step up.',
      'bark.kade.win1': 'Rift closes. I am still standing.',
      'bark.kade.win2': 'Tell the next era I am waiting.',
      'bark.kade.low1': 'Not done. Not yet.',
      'bark.kade.parry1': 'Read you.',
      'bark.kade.parry2': 'Too slow.',
      'bark.brakk.1': 'I break walls. You are thinner than a wall.',
      'bark.brakk.2': 'Hold still. It hurts less.',
      'bark.sable.1': 'Three cuts. Count them.',
      'bark.sable.2': 'You are slow. I checked.',
      'bark.quill.1': 'Stay right there. Perfect.',
      'bark.quill.2': 'Good wind tonight.',
      'bark.dax.1': 'One shot. I only ever need one.',
      'bark.dax.2': 'Do not blink.',
      'bark.ann.supply': 'Supply drop inbound!',
      'bark.ann.last': 'Final opponent!',
      'bark.ann.lose': 'The yard takes another one.',
    },
  };

  RR.locale = 'en';

  RR.t = function (key, vars) {
    const table = RR.LOCALES[RR.locale] || RR.LOCALES.en;
    let s = table[key];
    if (s === undefined) s = RR.LOCALES.en[key];
    if (s === undefined) return key;
    if (vars) s = s.replace(/\{(\w+)\}/g, (m, k) => (vars[k] !== undefined ? vars[k] : m));
    return s;
  };

  // Fill every element that declares data-i18n / data-i18n-aria.
  RR.applyI18n = function (root) {
    root = root || document;
    root.querySelectorAll('[data-i18n]').forEach((el) => {
      el.textContent = RR.t(el.getAttribute('data-i18n'));
    });
    root.querySelectorAll('[data-i18n-aria]').forEach((el) => {
      el.setAttribute('aria-label', RR.t(el.getAttribute('data-i18n-aria')));
    });
  };

  // Developer aid: a generated pseudo-locale that wraps every string in brackets.
  // Switching to it makes any hard-coded (un-localized) text easy to spot.
  RR.makePseudoLocale = function () {
    const zz = { _name: 'Pseudo' };
    for (const k in RR.LOCALES.en) if (k !== '_name') zz[k] = '⟦' + RR.LOCALES.en[k] + '⟧';
    RR.LOCALES.zz = zz;
  };
})();
