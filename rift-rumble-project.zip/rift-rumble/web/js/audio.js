/* Rift Rumble — audio. Every sound is synthesized with Web Audio, so the game ships no audio files. */
(function () {
  const RR = (window.RR = window.RR || {});
  let ctx = null, master, sfxBus, musicBus, noiseBuf, rainNode = null, rainGain = null;
  let musicMode = 'off', musicTimer = null, step = 0, nextTime = 0;

  function init() {
    if (ctx) {
      if (ctx.state === 'suspended') ctx.resume().catch(() => {});
      return true;
    }
    try {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return false;
      ctx = new AC();
      master = ctx.createGain();
      sfxBus = ctx.createGain();
      musicBus = ctx.createGain();
      sfxBus.connect(master);
      musicBus.connect(master);
      master.connect(ctx.destination);
      noiseBuf = ctx.createBuffer(1, ctx.sampleRate, ctx.sampleRate);
      const d = noiseBuf.getChannelData(0);
      for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
      applyVolumes();
      return true;
    } catch (e) {
      ctx = null;
      return false;
    }
  }

  function applyVolumes() {
    if (!ctx) return;
    const s = RR.settings;
    master.gain.value = s.master;
    sfxBus.gain.value = s.sfx;
    musicBus.gain.value = s.music * 0.55;
  }

  function tone(type, f0, f1, dur, vol, delay, bus) {
    const t = ctx.currentTime + (delay || 0);
    const o = ctx.createOscillator(), g = ctx.createGain();
    o.type = type;
    o.frequency.setValueAtTime(f0, t);
    if (f1 !== f0) o.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + dur);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(vol, t + 0.006);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g);
    g.connect(bus || sfxBus);
    o.start(t);
    o.stop(t + dur + 0.02);
  }

  function noise(dur, vol, ftype, f0, f1, delay, bus) {
    const t = ctx.currentTime + (delay || 0);
    const src = ctx.createBufferSource(), f = ctx.createBiquadFilter(), g = ctx.createGain();
    src.buffer = noiseBuf;
    src.loop = true;
    f.type = ftype;
    f.frequency.setValueAtTime(f0, t);
    if (f1 && f1 !== f0) f.frequency.exponentialRampToValueAtTime(f1, t + dur);
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    src.connect(f);
    f.connect(g);
    g.connect(bus || sfxBus);
    src.start(t, Math.random() * 0.5);
    src.stop(t + dur + 0.02);
  }

  const SFX = {
    punch() { noise(0.07, 0.5, 'lowpass', 900, 200); tone('sine', 150, 60, 0.1, 0.55); },
    heavy() { noise(0.12, 0.7, 'lowpass', 1200, 150); tone('sine', 120, 40, 0.2, 0.75); },
    swing() { noise(0.13, 0.2, 'bandpass', 600, 2400); },
    slash() { noise(0.09, 0.4, 'highpass', 2200, 2200); tone('triangle', 900, 300, 0.12, 0.22); },
    bow() { tone('triangle', 320, 140, 0.12, 0.3); noise(0.05, 0.12, 'highpass', 3000, 3000); },
    arrowhit() { noise(0.05, 0.35, 'bandpass', 1200, 1200); tone('sine', 200, 90, 0.08, 0.35); },
    rifle() { noise(0.22, 0.7, 'lowpass', 3200, 300); tone('square', 110, 40, 0.16, 0.3); },
    thunk() { noise(0.05, 0.25, 'bandpass', 700, 400); },
    block() { tone('square', 520, 380, 0.06, 0.2); noise(0.05, 0.25, 'bandpass', 2500, 2500); },
    parry() { tone('triangle', 1320, 1320, 0.22, 0.3); tone('triangle', 1980, 1980, 0.3, 0.18, 0.03); },
    guardbreak() { noise(0.2, 0.5, 'lowpass', 2000, 200); tone('sawtooth', 300, 80, 0.25, 0.3); },
    dodge() { noise(0.18, 0.2, 'bandpass', 400, 1700); },
    hurt() { tone('sawtooth', 230, 110, 0.12, 0.25); noise(0.06, 0.3, 'lowpass', 800, 300); },
    pickup() { tone('sine', 520, 780, 0.09, 0.28); tone('sine', 780, 1040, 0.1, 0.24, 0.08); },
    heal() { tone('sine', 440, 660, 0.12, 0.25); tone('sine', 660, 880, 0.12, 0.22, 0.1); tone('sine', 880, 1320, 0.16, 0.2, 0.2); },
    broken() { noise(0.12, 0.35, 'highpass', 1500, 600); tone('square', 300, 120, 0.14, 0.18); },
    ui() { tone('square', 660, 660, 0.04, 0.1); },
    uiback() { tone('square', 440, 440, 0.04, 0.1); },
    spawn() { tone('sawtooth', 90, 240, 0.4, 0.2); noise(0.35, 0.2, 'bandpass', 300, 1800); },
    crate() { noise(0.2, 0.6, 'lowpass', 700, 120); tone('sine', 90, 40, 0.25, 0.6); },
    warn() { tone('square', 980, 980, 0.05, 0.08); },
    ko() { noise(0.3, 0.6, 'lowpass', 1500, 100); tone('sine', 180, 35, 0.4, 0.7); },
    fight() { tone('sawtooth', 220, 440, 0.18, 0.25); tone('sawtooth', 330, 660, 0.3, 0.25, 0.12); noise(0.3, 0.3, 'highpass', 4000, 1500, 0.1); },
    win() { [523, 659, 784, 1047].forEach((f, i) => tone('triangle', f, f, 0.28, 0.3, i * 0.13)); tone('triangle', 1319, 1319, 0.6, 0.3, 0.55); },
    lose() { [392, 330, 262, 196].forEach((f, i) => tone('sawtooth', f, f * 0.97, 0.32, 0.2, i * 0.2)); },
  };

  /* ---- music: a small step sequencer, no samples ---------------------- */
  const BASS = [73.4, 0, 73.4, 0, 87.3, 0, 73.4, 73.4, 65.4, 0, 65.4, 0, 55, 0, 65.4, 82.4];
  const LEAD = [0, 0, 587, 0, 0, 523, 0, 0, 0, 0, 440, 0, 523, 0, 0, 0];
  function schedule() {
    if (!ctx || musicMode === 'off') return;
    const stepDur = 60 / 116 / 4;
    while (nextTime < ctx.currentTime + 0.2) {
      const d = Math.max(0, nextTime - ctx.currentTime);
      const s = step % 16;
      const fight = musicMode === 'fight';
      if (BASS[s]) tone('sawtooth', BASS[s], BASS[s], stepDur * 1.8, fight ? 0.22 : 0.12, d, musicBus);
      if (fight) {
        if (s % 4 === 0) { tone('sine', 140, 45, 0.14, 0.7, d, musicBus); }
        if (s % 4 === 2) noise(0.04, 0.18, 'highpass', 7000, 7000, d, musicBus);
        if (s === 4 || s === 12) noise(0.1, 0.3, 'bandpass', 1800, 1200, d, musicBus);
        if (LEAD[s] && step % 64 >= 32) tone('square', LEAD[s], LEAD[s], stepDur * 2, 0.06, d, musicBus);
      } else if (LEAD[s] && s % 2 === 0) {
        tone('triangle', LEAD[s] / 2, LEAD[s] / 2, stepDur * 6, 0.1, d, musicBus);
      }
      nextTime += stepDur;
      step++;
    }
  }

  RR.audio = {
    init,
    applyVolumes,
    sfx(name) {
      if (!ctx || ctx.state !== 'running' || !SFX[name]) return;
      try { SFX[name](); } catch (e) { /* ignore */ }
    },
    music(mode) {
      musicMode = mode;
      if (!ctx) return;
      if (mode === 'off') {
        if (musicTimer) { clearInterval(musicTimer); musicTimer = null; }
        return;
      }
      if (!musicTimer) {
        nextTime = ctx.currentTime + 0.05;
        step = 0;
        musicTimer = setInterval(schedule, 60);
      }
    },
    rain(on) {
      if (!ctx) return;
      if (on && !rainNode) {
        rainNode = ctx.createBufferSource();
        rainNode.buffer = noiseBuf;
        rainNode.loop = true;
        const f = ctx.createBiquadFilter();
        f.type = 'bandpass';
        f.frequency.value = 2200;
        f.Q.value = 0.4;
        rainGain = ctx.createGain();
        rainGain.gain.value = 0.09;
        rainNode.connect(f);
        f.connect(rainGain);
        rainGain.connect(sfxBus);
        rainNode.start();
      } else if (!on && rainNode) {
        try { rainNode.stop(); } catch (e) { /* ignore */ }
        rainNode = null;
      }
    },
    suspend() { if (ctx && ctx.state === 'running') ctx.suspend().catch(() => {}); },
    resume() { if (ctx && ctx.state === 'suspended') ctx.resume().catch(() => {}); },
    // Voice lines: Android wrapper bridge first, then the browser speech voice. Text only if neither exists.
    speak(text) {
      const s = RR.settings;
      if (!s.voice || s.master <= 0) return;
      try {
        if (window.RRNative && window.RRNative.speak) {
          window.RRNative.speak(text, s.master);
          return;
        }
        const synth = window.speechSynthesis;
        if (!synth || typeof window.SpeechSynthesisUtterance !== 'function') return;
        synth.cancel();
        const u = new window.SpeechSynthesisUtterance(text);
        u.lang = RR.locale;
        u.rate = 1.08;
        u.pitch = 0.9;
        u.volume = Math.min(1, s.master);
        synth.speak(u);
      } catch (e) { /* speech not available */ }
    },
    hush() {
      try { if (window.speechSynthesis) window.speechSynthesis.cancel(); } catch (e) { /* ignore */ }
    },
    get state() { return ctx ? ctx.state : 'none'; },
  };

  RR.vibrate = function (ms) {
    if (!RR.settings.vibrate) return;
    try { if (navigator.vibrate) navigator.vibrate(ms); } catch (e) { /* ignore */ }
  };
})();
