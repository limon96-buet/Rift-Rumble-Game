/* Rift Rumble — content registry.
 * Everything a match can roll from lives here as plain data, grouped by content pack.
 * To add a future pack: add a PACKS entry with status:'installed', then add arenas /
 * fighters / weapons that reference its id. Menus read from these tables; nothing
 * else in the code needs to know a pack exists.
 */
(function () {
  const RR = (window.RR = window.RR || {});

  /* ---- Content packs -------------------------------------------------- */
  // status: 'installed' = ships in this build. 'planned' = roadmap only, NOT in this build.
  RR.PACKS = [
    { id: 'core', status: 'installed' },
    { id: 'ancient', status: 'planned' },
    { id: 'early1900s', status: 'planned' },
    { id: 'prehistoric', status: 'planned', mode: 'survival' },
    { id: 'future', status: 'planned' },
    { id: 'climates', status: 'planned' },
  ];

  /* ---- Weapons --------------------------------------------------------
   * kind 'melee': range/arc sweep. kind 'ranged': spawns a projectile.
   * moves[]: w = wind-up, a = active, r = recovery (seconds). Melee moves carry dmg/knock.
   * All values are game-feel numbers for a fictional arcade brawler.
   */
  RR.WEAPONS = {
    fists: {
      kind: 'melee', range: 62, arc: 1.95, st: 5, lunge: 62, icon: 'fist',
      moves: [
        { w: 0.06, a: 0.07, r: 0.12, dmg: 7, knock: 90 },
        { w: 0.06, a: 0.07, r: 0.12, dmg: 7, knock: 90 },
        { w: 0.11, a: 0.09, r: 0.24, dmg: 13, knock: 260, heavy: true },
      ],
    },
    sword: {
      kind: 'melee', range: 100, arc: 2.45, st: 11, lunge: 78, uses: 16, icon: 'sword', pack: 'core',
      moves: [
        { w: 0.13, a: 0.1, r: 0.2, dmg: 18, knock: 170 },
        { w: 0.14, a: 0.1, r: 0.3, dmg: 24, knock: 280, heavy: true },
      ],
    },
    bow: {
      kind: 'ranged', st: 6, uses: 9, icon: 'bow', pack: 'core',
      proj: { speed: 840, dmg: 21, knock: 120, kind: 'arrow' },
      moves: [{ w: 0.3, a: 0.05, r: 0.26 }],
    },
    rifle: {
      kind: 'ranged', st: 4, uses: 5, icon: 'rifle', pack: 'core',
      proj: { speed: 1700, dmg: 32, knock: 230, kind: 'bolt' },
      moves: [{ w: 0.15, a: 0.05, r: 0.8 }],
    },
    /* Opponent-only variants: slower, clearly telegraphed. */
    ai_haymaker: {
      kind: 'melee', range: 72, arc: 1.75, st: 0, lunge: 120, icon: 'fist',
      moves: [{ w: 0.58, a: 0.1, r: 0.62, dmg: 15, knock: 290, heavy: true }],
    },
    ai_saber: {
      kind: 'melee', range: 98, arc: 2.2, st: 0, lunge: 150, icon: 'sword',
      moves: [{ w: 0.42, a: 0.1, r: 0.5, dmg: 13, knock: 170 }],
    },
    ai_bow: {
      kind: 'ranged', st: 0, icon: 'bow',
      proj: { speed: 600, dmg: 12, knock: 90, kind: 'arrow' },
      moves: [{ w: 0.85, a: 0.05, r: 0.9 }],
    },
    ai_rifle: {
      kind: 'ranged', st: 0, icon: 'rifle',
      proj: { speed: 1250, dmg: 19, knock: 180, kind: 'bolt' },
      moves: [{ w: 1.1, a: 0.05, r: 1.5 }],
    },
  };
  // Weapons that can appear as pickups in a match.
  RR.PICKUP_WEAPONS = ['sword', 'bow', 'rifle'];

  /* ---- Fighters ------------------------------------------------------- */
  RR.FIGHTERS = {
    kade: {
      pack: 'core', playable: true, r: 22, hp: 100, st: 100, speed: 235,
      look: 'runner', stats: { power: 3, speed: 4, guard: 3 },
    },
    brakk: {
      pack: 'core', r: 27, hp: 150, speed: 155, look: 'bruiser', weapon: 'ai_haymaker', poise: true,
      ai: { type: 'melee', cd: [0.5, 1.0], block: 0.3 },
    },
    sable: {
      pack: 'core', r: 21, hp: 105, speed: 218, look: 'duelist', weapon: 'ai_saber',
      ai: { type: 'melee', cd: [0.6, 1.1], hop: 0.6 },
    },
    quill: {
      pack: 'core', r: 21, hp: 80, speed: 178, look: 'archer', weapon: 'ai_bow',
      ai: { type: 'ranged', min: 230, max: 430, fireMax: 560, cd: [0.9, 1.6] },
    },
    dax: {
      pack: 'core', r: 23, hp: 95, speed: 142, look: 'gunner', weapon: 'ai_rifle',
      ai: { type: 'ranged', min: 300, max: 520, fireMax: 760, cd: [1.2, 2.0] },
    },
  };
  RR.OPPONENTS = ['brakk', 'sable', 'quill', 'dax'];
  // Slots shown (locked) on the fighter screen so the menu structure is ready for packs.
  RR.PLANNED_FIGHTER_SLOTS = 2;

  /* ---- Arenas --------------------------------------------------------- */
  RR.ARENAS = {
    sundial: {
      pack: 'core', w: 1500, h: 950, wall: 46,
      playerSpawn: { x: 750, y: 640 },
      spawns: [
        { x: 140, y: 150 }, { x: 1360, y: 150 }, { x: 140, y: 800 }, { x: 1360, y: 800 },
        { x: 750, y: 110 }, { x: 110, y: 475 }, { x: 1390, y: 475 },
      ],
      pickupSpots: [
        { x: 750, y: 300 }, { x: 330, y: 475 }, { x: 1170, y: 475 }, { x: 520, y: 800 }, { x: 980, y: 800 },
      ],
      obstacles: [
        { type: 'pillar', x: 520, y: 300, r: 46 },
        { type: 'pillar', x: 980, y: 300, r: 46 },
        { type: 'pillar', x: 420, y: 660, r: 46 },
        { type: 'pillar', x: 1080, y: 660, r: 46 },
        { type: 'gnomon', x: 750, y: 475, r: 40 },
        { type: 'crate', x: 190, y: 250, w: 70, h: 70 },
        { type: 'crate', x: 1240, y: 640, w: 70, h: 70 },
      ],
    },
  };
  // Roadmap arenas — listed in the menu as "planned", with no gameplay data in this build.
  RR.PLANNED_ARENAS = [
    { id: 'bronzegate', pack: 'ancient' },
    { id: 'steamworks', pack: 'early1900s' },
    { id: 'ferncanyon', pack: 'prehistoric' },
    { id: 'neonflats', pack: 'future' },
  ];

  /* ---- Match conditions (weather / time of day) ----------------------- */
  RR.CONDITIONS = {
    clear: {},
    fog: { vision: 300 },
    rain: { slick: true },
    night: { dark: true },
  };
  RR.CONDITION_IDS = ['clear', 'fog', 'rain', 'night'];

  /* ---- Difficulty ----------------------------------------------------- */
  RR.DIFFICULTY = {
    easy: { enemyDmg: 0.7, enemyHp: 0.85, windup: 1.25, cd: 1.35, attackers: 1, count: 3, orb: 1, score: 0.8 },
    normal: { enemyDmg: 1, enemyHp: 1, windup: 1, cd: 1, attackers: 2, count: 3, orb: 0.6, score: 1 },
    hard: { enemyDmg: 1.15, enemyHp: 1.1, windup: 0.9, cd: 0.85, attackers: 2, count: 4, orb: 0.5, score: 1.3 },
  };

  /* ---- Voice lines (keys into the locale table) ------------------------ */
  RR.BARKS = {
    start: ['bark.kade.start1', 'bark.kade.start2', 'bark.kade.start3'],
    win: ['bark.kade.win1', 'bark.kade.win2'],
    low: ['bark.kade.low1'],
    parry: ['bark.kade.parry1', 'bark.kade.parry2'],
    brakk: ['bark.brakk.1', 'bark.brakk.2'],
    sable: ['bark.sable.1', 'bark.sable.2'],
    quill: ['bark.quill.1', 'bark.quill.2'],
    dax: ['bark.dax.1', 'bark.dax.2'],
    supply: ['bark.ann.supply'],
    last: ['bark.ann.last'],
    lose: ['bark.ann.lose'],
  };
})();
